
  clear all;
  close all;
  addpath(genpath('Utilize\'));
  kernel_type     =   'Uniform_blur';
  sf              =    8;
  load('C:\Users\owuchangyuo\Desktop\WLRTR\Data\Part_chart_and_stuffed_toy_msUint8.mat')
  O_Img = O_ImgUint8/max(O_ImgUint8(:));
  Z_ori = reshape(O_Img,[size(O_Img,1)*size(O_Img,2),size(O_Img,3)])';
  rand('seed',0);
  par             =    ParamSR_setting( sf, kernel_type, [size(O_Img,1), size(O_Img,2)]);
  X               =    par.H(Z_ori);
  par.P           =    create_P();
  Y               =    par.P*Z_ori;
  HSI             =    LRTR_SR_Main(X, Y, par, Z_ori, sf );
  E_Img           =    reshape(HSI',[size(O_Img,1),size(O_Img,2),size(O_Img,3)]);