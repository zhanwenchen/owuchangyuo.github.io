    close all;
    clear all;
    addpath(genpath('Data\')); 
    addpath(genpath('Utilize\'));   
    nSig = 20;    
%     [filename, filepath, FilterIndex ] = uigetfile('data/*.*','Read image');
%     O_Img =  double(imread(fullfile(filepath,filename))) ;
    load('C:\Users\owuchangyuo\Desktop\WLRTR\Data\chart_and_stuffed_toy_msUint8.mat')
    O_Img = O_ImgUint8;
    randn('seed', 0);
    N_Img = O_Img + nSig * randn(size(O_Img));                                   %Generate noisy image   
    PSNR  =  csnr( N_Img, O_Img, 0, 0 );
    SSIM  = cal_ssim( N_Img, O_Img, 0, 0 ); 
    fprintf( 'Noisy Image: nSig = %2.3f, PSNR = %2.2f, SSIM = %2.3f,\n\n\n', nSig, PSNR,SSIM );
    Par   = ParSet(nSig); 
    [E_Img]= LRTR_DeNoising( N_Img, O_Img, Par);  %LRTA denoisng function