% clc;
clear all;
close all;
addpath(genpath('Utilize\'));

noise = [20];
randn('seed', 0);

for j =1:length(noise)
nSig =noise(j);

Original_image_dir    =    'Data\MatUint8';
Output_dir    =   ['Results\Denoising_results\nsig_',num2str(nSig)];
mkdir(Output_dir); 
pre           =   'ALL_Denoising_';
fpath         =   fullfile(Original_image_dir, '*.mat');
im_dir        =   dir(fpath);
im_num        =   length(im_dir);
sum_psnr      =   0;
sum_ssim      =   0;
time0         =   clock;
fn_txt        =   strcat( pre, 'PSNR_SSIM.txt' ); 
fd_txt        =   fopen( fullfile(Output_dir, fn_txt), 'wt');
PSNR_Value    =   zeros(1,im_num);
SSIM_Value    =   zeros(1,im_num);
SAM_Value     =   zeros(1,im_num);
ERGAS_Value   =   zeros(1,im_num);
for i = 1:im_num
%     O_Img      =   double( imread(fullfile(Original_image_dir, im_dir(i).name)) );
    load(fullfile(Original_image_dir, im_dir(i).name))
    O_Img      =   O_ImgUint8;
    N_Img      =   O_Img + nSig * randn(size(O_Img)); 

% %% BM4D restore results
%     tic
%     [BM4D_Img, ~] = bm4d(N_Img, 'Gauss', (~0)*nSig, 'mp', 1, 1);
%     toc
%     PSNR_BM4D  =  csnr( O_Img, BM4D_Img, 0, 0 );
%     SSIM_BM4D  =  cal_ssim( O_Img, BM4D_Img, 0, 0 ); 
%     SAM_BM4D   = SpectAngMapper(O_Img, BM4D_Img);
%     ERGAS_BM4D = ErrRelGlobAdimSyn(O_Img, BM4D_Img);
%     fprintf( sprintf('%s: PSNR_BM4D = %3.2f  SSIM_BM4D = %f SAM_BM4D =%f  ERGAS_BM4D =%f \n', im_dir(i).name, PSNR_BM4D, SSIM_BM4D, SAM_BM4D, ERGAS_BM4D) );
%     fprintf(fd_txt, '%s : PSNR_BM4D = %2.2f  SSIM_BM4D = %2.4f SAM_BM4D =%f  ERGAS_BM4D =%f \n', im_dir(i).name, PSNR_BM4D, SSIM_BM4D, SAM_BM4D, ERGAS_BM4D); 

% %% LRTDTV restore results
%     tau    = 1;
%     lambda = 100000; beta = 100;
%     Rank   = [75,75,10];
%     LRTDTV_Img  = LRTDTV_G(N_Img*255, tau,lambda,beta,Rank);
%     LRTDTV_Img = LRTDTV_Img * 255;
%     PSNR_LRTDTV  =  csnr( O_Img, LRTDTV_Img, 0, 0 );
%     SSIM_LRTDTV  =  cal_ssim( O_Img, LRTDTV_Img, 0, 0 ); 
%     SAM_LRTDTV   = SpectAngMapper(O_Img, LRTDTV_Img);
%     ERGAS_LRTDTV = ErrRelGlobAdimSyn(O_Img, LRTDTV_Img);
%     fprintf( sprintf('%s: PSNR_LRTDTV = %3.2f  SSIM_LRTDTV = %f SAM_LRTDTV =%f  ERGAS_LRTDTV =%f \n', im_dir(i).name, PSNR_LRTDTV, SSIM_LRTDTV, SAM_LRTDTV, ERGAS_LRTDTV) );
%     fprintf(fd_txt, '%s : PSNR_LRTDTV = %2.2f  SSIM_LRTDTV = %2.4f SAM_LRTDTV =%f  ERGAS_LRTDTV =%f \n', im_dir(i).name, PSNR_LRTDTV, SSIM_LRTDTV, SAM_LRTDTV, ERGAS_LRTDTV); 

% %% PARAFAC restore results
%     tic
%     [PARAFAC_Img, k] = PARAFAC(N_Img);
%     toc
%     PSNR_PARAFAC  =  csnr( O_Img, PARAFAC_Img, 0, 0 );
%     SSIM_PARAFAC  =  cal_ssim( O_Img, PARAFAC_Img, 0, 0 );
%     SAM_PARAFAC = SpectAngMapper(O_Img, PARAFAC_Img);
%     ERGAS_PARAFAC = ErrRelGlobAdimSyn(O_Img, PARAFAC_Img);
%     fprintf( sprintf('%s: PSNR_PARAFAC = %3.2f  SSIM_PARAFAC = %f SAM_PARAFAC = %f  ERGAS_PARAFAC = %f \n', im_dir(i).name, PSNR_PARAFAC, SSIM_PARAFAC, SAM_PARAFAC, ERGAS_PARAFAC) );
%     fprintf(fd_txt, '%s : PSNR_PARAFAC = %2.2f  SSIM_PARAFAC = %2.4f SAM_PARAFAC = %f  ERGAS_PARAFAC = %f \n', im_dir(i).name, PSNR_PARAFAC, SSIM_PARAFAC, SAM_PARAFAC, ERGAS_PARAFAC);     

% %% SDS restore results
%     [SDS_Img,~] = denoise(shiftdim(N_Img,2));
%     PSNR_SDS  =  csnr( O_Img, shiftdim(SDS_Img,1), 0, 0 );
%     SSIM_SDS  =  cal_ssim( O_Img, shiftdim(SDS_Img,1), 0, 0 ); 
%     SAM_SDS   = SpectAngMapper(O_Img, shiftdim(SDS_Img,1));
%     ERGAS_SDS = ErrRelGlobAdimSyn(O_Img, shiftdim(SDS_Img,1));
%     fprintf( sprintf('%s: PSNR_SDS = %3.2f  SSIM_SDS = %f SAM_SDS = %f  ERGAS_SDS = %f \n', im_dir(i).name, PSNR_SDS, SSIM_SDS, SAM_SDS , ERGAS_SDS ) );
%     fprintf(fd_txt, '%s : PSNR_SDS = %2.2f  SSIM_SDS = %2.4f SAM_SDS = %f  ERGAS_SDS = %f \n', im_dir(i).name, PSNR_SDS, SSIM_SDS, SAM_SDS, ERGAS_SDS); 
    
% %% ANLM restore results
%     min_val = min(N_Img(:));
%     TN_Img  = N_Img - min_val;
%     tic
%     fimau = MABONLM3D(TN_Img, 3, 1, 0);
%     fimao = MABONLM3D(TN_Img, 3, 2, 0);
%     toc
%     ANLM_Img = mixingsubband(fimau, fimao) + min_val;
%     PSNR_ANLM  =  csnr( O_Img, ANLM_Img, 0, 0 );
%     SSIM_ANLM =  cal_ssim( O_Img, ANLM_Img, 0, 0 ); 
%     SAM_ANLM   = SpectAngMapper(O_Img,ANLM_Img);
%     ERGAS_ANLM = ErrRelGlobAdimSyn(O_Img, ANLM_Img);
%     fprintf( sprintf('%s: PSNR_ANLM = %3.2f  SSIM_ANLM = %f SAM_ANLM = %f  ERGAS_ANLM = %f \n', im_dir(i).name, PSNR_ANLM, SSIM_ANLM, SAM_ANLM , ERGAS_ANLM ) );
%     fprintf(fd_txt, '%s : PSNR_ANLM = %2.2f  SSIM_ANLM = %2.4f SAM_ANLM = %f  ERGAS_ANLM = %f \n', im_dir(i).name, PSNR_ANLM, SSIM_ANLM, SAM_ANLM, ERGAS_ANLM);    

% %% SSTV restore results
%     SSTV_Img  =   funSSTV(N_Img,30,0.1,3,0.2);
%     PSNR_SSTV  =  csnr( O_Img, SSTV_Img, 0, 0 );
%     SSIM_SSTV  =  cal_ssim( O_Img, SSTV_Img, 0, 0 ); 
%     SAM_SSTV   = SpectAngMapper(O_Img,SSTV_Img);
%     ERGAS_SSTV = ErrRelGlobAdimSyn(O_Img, SSTV_Img);
%     fprintf( sprintf('%s: PSNR_SSTV = %3.2f  SSIM_SSTV = %f SAM_SSTV = %f  ERGAS_SSTV = %f \n', im_dir(i).name, PSNR_SSTV, SSIM_SSTV, SAM_SSTV , ERGAS_SSTV ) );
%     fprintf(fd_txt, '%s : PSNR_SSTV = %2.2f  SSIM_SSTV = %2.4f SAM_SSTV = %f  ERGAS_SSTV = %f \n', im_dir(i).name, PSNR_SSTV, SSIM_SSTV, SAM_SSTV, ERGAS_SSTV);               
    
% %% NMF restore results
%     tic
%     [NMF_Img, A, S] = nmf_denoising(N_Img, [7,7], 2, 98, nSig*3);
%     toc
%     PSNR_NMF  =  csnr( O_Img, NMF_Img, 0, 0 );
%     SSIM_NMF  =  cal_ssim( O_Img, NMF_Img, 0, 0 ); 
%     SAM_NMF   = SpectAngMapper(O_Img,NMF_Img);
%     ERGAS_NMF = ErrRelGlobAdimSyn(O_Img, NMF_Img);
%     fprintf( sprintf('%s: PSNR_NMF = %3.2f  SSIM_NMF = %f SAM_NMF = %f  ERGAS_NMF = %f \n', im_dir(i).name, PSNR_NMF, SSIM_NMF, SAM_NMF , ERGAS_NMF ) );
%     fprintf(fd_txt, '%s : PSNR_NMF = %2.2f  SSIM_NMF = %2.4f SAM_NMF = %f  ERGAS_NMF = %f \n', im_dir(i).name, PSNR_NMF, SSIM_NMF, SAM_NMF, ERGAS_NMF);    
    
% %% TDL restore results
%     vstbmtf_params.peak_value = 1;
%     vstbmtf_params.nsigma = nSig;
%     tic
%     TDL_Img = TensorDL(N_Img/256, vstbmtf_params);
%     toc
%     PSNR_TDL  =  csnr( O_Img, TDL_Img*256, 0, 0 );
%     SSIM_TDL  =  cal_ssim( O_Img, TDL_Img*256, 0, 0 ); 
%     SAM_TDL   = SpectAngMapper(O_Img,TDL_Img*256);
%     ERGAS_TDL = ErrRelGlobAdimSyn(O_Img, TDL_Img*256);
%     fprintf( sprintf('%s: PSNR_TDL = %3.2f  SSIM_TDL = %f SAM_TDL = %f  ERGAS_TDL = %f \n', im_dir(i).name, PSNR_TDL, SSIM_TDL, SAM_TDL , ERGAS_TDL ) );
%     fprintf(fd_txt, '%s : PSNR_TDL = %2.2f  SSIM_TDL = %2.4f SAM_TDL = %f  ERGAS_TDL = %f \n', im_dir(i).name, PSNR_TDL, SSIM_TDL, SAM_TDL, ERGAS_TDL);   
     
% %% BM3D restore results
%     tic
%     BM3D_Img   =  N_Img;
%     for k = 1:size(N_Img,3)
%         [~, BM3D_Img(:,:,k)] = BM3D(1,N_Img(:,:,k), nSig);
%     end
%     toc
%     PSNR_BM3D  =  csnr( O_Img, 256*BM3D_Img, 0, 0 );
%     SSIM_BM3D  =  cal_ssim( O_Img, 256*BM3D_Img, 0, 0 ); 
%     SAM_BM3D   = SpectAngMapper(O_Img,256*BM3D_Img);
%     ERGAS_BM3D = ErrRelGlobAdimSyn(O_Img, 256*BM3D_Img);
%     fprintf( sprintf('%s: PSNR_BM3D = %3.2f  SSIM_BM3D = %f SAM_BM3D = %f  ERGAS_BM3D = %f \n', im_dir(i).name, PSNR_BM3D, SSIM_BM3D, SAM_BM3D , ERGAS_BM3D ) );
%     fprintf(fd_txt, '%s : PSNR_BM3D = %2.2f  SSIM_BM3D = %2.4f SAM_BM3D = %f  ERGAS_BM3D = %f \n', im_dir(i).name, PSNR_BM3D, SSIM_BM3D, SAM_BM3D, ERGAS_BM3D);   

% %% LRMR restore results
%     Par        =  ParamSet(nSig);
%     tic
%     LRMR_Img   =  LRMR_DeNoising( N_Img, Par );
%     toc
%     PSNR_LRMR  =  csnr( O_Img, LRMR_Img, 0, 0 );
%     SSIM_LRMR  =  cal_ssim( O_Img, LRMR_Img, 0, 0 ); 
%     SAM_LRMR   = SpectAngMapper(O_Img,LRMR_Img);
%     ERGAS_LRMR = ErrRelGlobAdimSyn(O_Img, LRMR_Img);
%     fprintf( sprintf('%s: PSNR_LRMR = %3.2f  SSIM_LRMR = %f SAM_LRMR = %f  ERGAS_LRMR = %f \n', im_dir(i).name, PSNR_LRMR, SSIM_LRMR, SAM_LRMR , ERGAS_LRMR ) );
%     fprintf(fd_txt, '%s : PSNR_LRMR = %2.2f  SSIM_LRMR = %2.4f SAM_LRMR = %f  ERGAS_LRMR = %f \n', im_dir(i).name, PSNR_LRMR, SSIM_LRMR, SAM_LRMR, ERGAS_LRMR);    
    
% %% ISTreg restore results
%     ISTReg_Img = ITS_DeNoising(N_Img/256,nSig/256,O_Img/256);
%     PSNR_ISTReg  =  csnr( O_Img, 256*ISTReg_Img, 0, 0 );
%     SSIM_ISTReg  =  cal_ssim( O_Img, 256*ISTReg_Img, 0, 0 ); 
%     SAM_ISTReg   = SpectAngMapper(O_Img,256*ISTReg_Img);
%     ERGAS_ISTReg = ErrRelGlobAdimSyn(O_Img, 256*ISTReg_Img);
%     fprintf( sprintf('%s: PSNR_ISTReg = %3.2f  SSIM_ISTReg = %f SAM_ISTReg = %f  ERGAS_ISTReg = %f \n', im_dir(i).name, PSNR_ISTReg, SSIM_ISTReg, SAM_ISTReg , ERGAS_ISTReg ) );
%     fprintf(fd_txt, '%s : PSNR_ISTReg = %2.2f  SSIM_ISTReg = %2.4f SAM_ISTReg = %f  ERGAS_ISTReg = %f \n', im_dir(i).name, PSNR_ISTReg, SSIM_ISTReg, SAM_ISTReg, ERGAS_ISTReg);    
    
%% LRTR restore results
    Par   = ParSet(nSig);  
    [E_Img]   =  LRTR_DeNoising( N_Img, O_Img, Par );     
    PSNR_LRTR  =  csnr( O_Img, E_Img, 0, 0 );
    SSIM_LRTR  =  cal_ssim( O_Img, E_Img, 0, 0 ); 
    SAM_LRTR   = SpectAngMapper(O_Img,E_Img);
    ERGAS_LRTR = ErrRelGlobAdimSyn(O_Img, E_Img);
    fprintf( sprintf('%s: PSNR_LRTR = %3.2f  SSIM_LRTR = %f SAM_LRTR = %f  ERGAS_LRTR = %f \n', im_dir(i).name, PSNR_LRTR, SSIM_LRTR, SAM_LRTR , ERGAS_LRTR ) );
    fprintf(fd_txt, '%s : PSNR_LRTR = %2.2f  SSIM_LRTR = %2.4f SAM_LRTR = %f  ERGAS_LRTR = %f \n', im_dir(i).name, PSNR_LRTR, SSIM_LRTR, SAM_LRTR, ERGAS_LRTR);   

%% Quantitative Assessment
    PSNR_Value(:,i) = [PSNR_LRTR];
    SSIM_Value(:,i) = [SSIM_LRTR];
    SAM_Value(:,i) = [SAM_LRTR];
    ERGAS_Value(:,i) = [ERGAS_LRTR];

end
% PSNR_ANLM=mean(PSNR_Value);SSIM_ANLM=mean(SSIM_Value);SAM_ANLM=mean(SAM_Value);ERGAS_ANLM=mean(ERGAS_Value);
% fprintf( sprintf('%s: PSNR_ANLM = %3.2f  SSIM_ANLM = %f SAM_ANLM = %f  ERGAS_ANLM = %f \n', 'Average', PSNR_ANLM, SSIM_ANLM, SAM_ANLM , ERGAS_ANLM ) );
% fprintf(fd_txt, '%s : PSNR_ANLM = %2.2f  SSIM_ANLM = %2.4f SAM_ANLM = %f  ERGAS_ANLM = %f \n', 'Average', PSNR_ANLM, SSIM_ANLM, SAM_ANLM, ERGAS_ANLM);   
fclose(fd_txt);
end
fprintf(sprintf('Total elapsed time = %f min\n', (etime(clock,time0)/60) ));