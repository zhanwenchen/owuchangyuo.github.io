
  clc;
  clear all;
  close all;
  addpath(genpath('Utilize\'));
  kernel_type     =    'Gaussian_blur';
  % kernel_type     =    'Uniform_blur';
  load('C:\Users\owuchangyuo\Desktop\WLRTR\Data\Part_chart_and_stuffed_toy_msUint8.mat')
  Z_ori = double(O_ImgUint8)/256;
  rand('seed',0);
  nlevel          =    0/256;
  wrapSize        =    6;
  
  for band = 1:size(Z_ori,3)
    O_Img(:,:,band) =    wrap_boundary_liu( Z_ori(:,:,band), opt_fft_size( [size(Z_ori,1), size(Z_ori,2)] + wrapSize ) );   % bounary extension
  end
  par             =    ParamDeblur_setting( nlevel,O_Img );
  Y_Img           =    par.B(O_Img);
  E_Img           =    LRTR_Deblur_Main(O_Img, Y_Img, par);
  HSI_res         =    E_Img(1:size(Z_ori,1),1:size(Z_ori,2),:);
