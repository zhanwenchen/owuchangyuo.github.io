
function Y  =  ITSReg(D,beta,Par)
% sloving following ITS-based tensor recovery problem.
% min_X P_ls( C ) + lambda Prod_j{(P_ls^*( M_j(j))} + beta/2*| Y - ttm(C,{U_1,U_2,...,U_N}) |_F^2
% s.t.  ttm(C,{U_1,U_2,...,U_N}) - M_j = 0, forall j =  1,2,..,N;
%
% Input arguments:
%   D      ...... the corrupted tensor. Please make sure D is in range [0, 1].
%   beta   ...... the compromise parameter.
%   Par    ...... an option structure whose fields are as follows:
%      lambda ... the compromise parameter in ITS, usually setted in [0.1,10];
%      mu     ... initial mu in ADMM algorithm;
%      rho    ... parameter control the increasing speed of mu
%      maxIter .. max iteration step number
%
% Output arguments:
%   Y     ......  the reconstruct tensor 
%
% more detail can be found in [1]
% [1] Q. Xie, Q. Zhao, D. Meng, Z. Xu, S. Gu, W. Zuo, and L. Zhang.  Multispectral images denoising by intrinsic tensor sparsity regularization. In CVPR, 2016.
%
% @inproceedings{Xie2016multispectral,
%   title={Multispectral Images Denoising by Intrinsic Tensor Sparsity Regularization},
%   author={Xie, Qi and Zhao, Qian and Meng, Deyu and Xu, Zongben and Gu, Shuhang and Zuo, Wangmeng and Zhang, Lei},
%   booktitle={CVPR},
%   year={2016},
% }
%
% by Qi Xie
%==========================================================================
sizeD          = size(D);
ndim           = length(sizeD);
dim1Xdim2      = circshift(sizeD, [1,1]).*circshift(sizeD, [2,2]);
Rank0          = min(sizeD,dim1Xdim2);
Rank           = ones(1,ndim)*6;
Rank(1)        = sizeD(1)-20;

lambda         = Par.lambda    ;
mu             = Par.mu        ;
rho            = Par.rho       ;
maxIter        = Par.maxIter   ;
%% initialization about M
M         = cell(ndim, 1);
Lam       = cell(ndim, 1);
tempX     = cell(ndim, 1);
sValue    = cell(ndim, 1);
Mnorm     = zeros(ndim, 1);
Msum      = zeros(sizeD);
for i = 1:ndim
    M{i}      = D;
    Lam{i}    = zeros(sizeD);
    tempX{i}  = Unfold(D, sizeD, i);
    sValue{i} = svd(tempX{i}, 'econ');
    Mnorm(i)  = min(sum(sValue{i}>5),Rank(i));
    Msum      = Msum + Fold(M{i},sizeD,i);
end
alpha     = circshift(Mnorm, [1,1]).*circshift(Mnorm, [2,2]); %computing the  weigth
mu        = mu*(1+1/lambda);
beta      = beta*(1+1/lambda);

%% initialization about C
[C,U,n]        = initUC(D,10/beta,3,Rank);
Ut             = cell(ndim,1);
[C, ~]         = ClosedWL1(C,10/beta,eps);

%% initialization about other parameters
LamSum    = zeros(sizeD);
temp_n    = zeros(1,ndim);
Y         = zeros(sizeD);
%% main loop
for i = 1:maxIter    
    %% updating U
    for j = 1:ndim
        unfoTemp    = Unfold((beta*D+mu*Msum-LamSum)/(beta+ndim*mu), sizeD, j);
        tempC       = my_ttm(C,U,[1:j-1,j+1:ndim],Rank,sizeD,ndim);
        UnfoldC     = Unfold( tempC, Rank, j);
        tempMatix   = unfoTemp*UnfoldC';
        [V1,~,V2]   = svd(tempMatix,'econ');
        U{j}     = V1*V2';
        Ut{j}    = U{j}';
    end
    C       = my_ttm((beta*D+mu*Msum-LamSum)/(beta+ndim*mu),Ut,1:ndim,sizeD,Rank,ndim);
    [C, n]  = ClosedWL1(C,1/(beta+ndim*mu),eps);
    %% calculating Y
    Y       = my_ttm(C,U,1:ndim,Rank,sizeD,ndim);
    %% updating M
    Msum   = 0*Msum;
    LamSum = 0*LamSum;
    for k = 1:ndim
        [tempX{k}, temp_n(k), sValue{k}, Mnorm(k)] = Pro2WNNM(Unfold(Y + Lam{k}/mu, sizeD, k), lambda*alpha(k)/mu);%,Rank(k));
        M{k}      = Fold(tempX{k}, sizeD, k);
        Msum      = Msum + M{k};
        alpha     = circshift(Mnorm, [1,1]).*circshift(Mnorm, [2,2]); %computing the  weigth
        Lam{k}    = Lam{k}+mu*(Y-M{k});
        LamSum    = LamSum + Lam{k}; % updating the multipliers
    end  
    %% change rank to speedup
    [C,U,Rank] = ChangerRank(C,U,Rank,temp_n,Rank0,ndim,sizeD);
    %% updating mu
    mu         = mu*rho;
end
end

function [C,U,n] = initUC(Y,lambda,maxiter,Rank)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%min_{C,U1,U2}  lambda|C|_w.1+|Y-ttm[C;U1,U2,I]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sizeY          = size(Y);
[C, U]         = tensorSVD(Y, Rank);
ndim           = length(sizeY);
Ut             = cell(ndim,1);
for i = 1:maxiter
    for j = 1:ndim
        unfoTemp    = Unfold(Y, sizeY, j);
        tempC       = my_ttm(C,U,[1:j-1,j+1:ndim],Rank,sizeY,ndim);
        UnfoldC     = Unfold( tempC, Rank, j);
        tempMatix   = unfoTemp*UnfoldC';
        [V1,~,V2]   = svd(tempMatix,'econ');
        U{j}     = V1*V2';
        Ut{j}    = U{j}';
    end
    C       = my_ttm(Y,Ut,1:ndim,sizeY,Rank,ndim);
    [C, n]  = ClosedWL1(C,lambda,eps);
end
end

function [C,U,Rank] = ChangerRank(C,U,Rank,tempR,Rank0,ndim,sizeD)
IndChange  = find(tempR>Rank);
newR       = min(Rank+2,Rank0);
for i = IndChange(1:end)
    newR(i) = min(Rank(i)+4,Rank0(i));
end
if ~isequal(newR,Rank)
    if sum(newR>Rank)>0
        IndBiger  = find(newR>Rank);
        for i = IndBiger(1:end)
            temp = zeros(sizeD(i),newR(i));
            temp(:,1:Rank(i)) = U{i};
            U{i} = temp;
        end
        ind       = true(Rank);
        Rank      = max(newR,Rank);
        temp      = zeros(Rank);
        temp(ind) = C;
        C         = temp;
    end
    %% sorting a tensor
    for i = 1:ndim
        tempC      = Unfold(C,Rank,i);
        tempNorm   = sum(tempC.^2,2);
        [~,Ind] = sort(tempNorm,'descend');
        tempC      = tempC(Ind(1:newR(i)),:);
        Rank(i)    = newR(i);
        C          = Fold(tempC,Rank,i);
        U{i} = U{i}(:,Ind(1:newR(i)));
    end
end
end

