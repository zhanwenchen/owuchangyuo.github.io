function [Emsi] = ITS_DeNoising(Nmsi,nSig,Omsi)
% MSI denoising based on ITSReg
%
% Input arguments:
%   Nmsi   ...... the MSI corrupted by tensor. Please make sure this MSI is of size height x width x nbands and in range [0, 1].
%   nSig   ...... the variance of noise.
%   Omsi   ...... the clean MSI use to calculate PSNR, this argument is not nesscery.
%
% Output arguments:
%   Emsi   ......  the denoised MSI 
%
% more detail can be found in [1]
% [1] Q. Xie, Q. Zhao, D. Meng, Z. Xu, S. Gu, W. Zuo, and L. Zhang.  Multispectral images denoising by intrinsic tensor sparsity regularization. In CVPR, 2016.
%
% @inproceedings{Xie2016multispectral,
%   title={Multispectral Images Denoising by Intrinsic Tensor Sparsity Regularization},
%   author={Xie, Qi and Zhao, Qian and Meng, Deyu and Xu, Zongben and Gu, Shuhang and Zuo, Wangmeng and Zhang, Lei},
%   booktitle={CVPR},
%   year={2016},
% }
%
% by Qi Xie
%==========================================================================

if nargin<2
    error('no input nSig')
end
if nargin<3
    OutPSNR = 0;
else
    OutPSNR = 1;    
end
sizeData        = size(Nmsi);
[par, parBSM]   = Parsetting(nSig); % set denoising parameters and tensor recvery parameters;
Npatch          = Im2Patch3D(Nmsi, par);
sizePatch       = size(Npatch);
Emsi            = Nmsi;
[Sel_arr]       =  nonLocal_arr(sizeData, par); % PreCompute the all the patch index in the searching window 
L               =   length(Sel_arr);
%% main loop
tic
for  iter = 1 : par.deNoisingIter 
    Curmsi      	= Emsi + par.delta*(Nmsi - Emsi);                                  
    Curpatch        = Im2Patch3D(Curmsi, par); % image to FBPs    
    if(iter==1)
        Sigma_arr   = par.SigLam*par.nSig * ones(1,L); % First Iteration use the input noise parameter
    else
        temp        = sum(sum((Curpatch(:,:,Sel_arr)-Npatch(:,:,Sel_arr)).^2,1),2)/prod(sizePatch(1:2));
        Sigma_arr   = par.SigLam*sqrt(abs(par.nSig^2*ones(1,L)- temp(:)')); % estimate local noise variance
        parBSM.maxIter = max(parBSM.maxIter-10,15);
    end
    % block matching to find samilar FBP goups
    unfoldPatch     = Unfold(Curpatch,sizePatch,3)';
    patchXpatch     = sum(unfoldPatch.*unfoldPatch,1);
    distenMat       = repmat(patchXpatch(Sel_arr),sizePatch(3),1)+repmat(patchXpatch',1,L)-2*(unfoldPatch')*unfoldPatch(:,Sel_arr);
    [~,index]       = sort(distenMat);
    index           = index(1:par.patnum,:);
    clear patchXpatch distenMat;
    % block matching to find samilar FBP goups
    
    %     [Neighbor_arr, Num_arr, SelfIndex_arr]  =  NeighborIndex(Curmsi, par);
    %     [index]  =  Block_matching3D(Curpatch, par, Neighbor_arr,Num_arr,SelfIndex_arr);
    
    tempPatch       = cell(L,1);
    Epatch          = zeros(sizePatch);
    W               = zeros(sizePatch(1),sizePatch(3));
    
    for i = 1:L
        tempPatch{i} = Curpatch(:,:,index(:,i));
    end
    parfor i = 1:L  
        tempPatch{i} = ITSReg(tempPatch{i},1/Sigma_arr(i),parBSM); % Perform ITS-based tensor recovery on each FBP goup
    end
    for i = 1:L
        Epatch(:,:,index(:,i))  = Epatch(:,:,index(:,i)) + tempPatch{i};
        W(:,index(:,i))         = W(:,index(:,i))+ones(size(tempPatch{i},1),size(tempPatch{i},3));
    end 
    time = toc;
    [Emsi, ~]  =  Patch2Im3D( Epatch, W, par, sizeData); % recconstruct the estimated MSI by aggregating all reconstructed FBP goups.

    if OutPSNR
        psnr       =  PSNR3D(Emsi*255,Omsi*255);
        disp(['Iter: ' num2str(iter),' , current PSNR = ' num2str(psnr), ',  already cost time: ', num2str(time)]);
%         figure;imshow(Emsi(:,:,end));pause(0.5);
    else
        disp(['Iter: ' num2str(iter),'   done  ']);
    end
end
end

function  [SelfIndex_arr]  =  nonLocal_arr(sizeD, par)
% -SelfIndex_arr is the index of keypatches in the total patch index array 
TempR         =   sizeD(1)-par.patsize+1;
TempC         =   sizeD(2)-par.patsize+1;
R_GridIdx	  =   1:par.step:TempR;
R_GridIdx	  =   [R_GridIdx R_GridIdx(end)+1:TempR];
C_GridIdx	  =   1:par.step:TempC;
C_GridIdx	  =   [C_GridIdx C_GridIdx(end)+1:TempC];

temp          = 1:TempR*TempC;
temp          = reshape(temp,TempR,TempC);
SelfIndex_arr = temp(R_GridIdx,C_GridIdx);
SelfIndex_arr = SelfIndex_arr(:)';
end

