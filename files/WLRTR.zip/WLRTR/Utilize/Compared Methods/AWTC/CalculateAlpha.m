%%Calculate Alpha
% dim=size(T)
function [alpha] =CalculateAlpha(tensor,percentage)
  rankmax=[1,1,1];%��ʼ��
  tensor1=Unfold(tensor,size(tensor),1);
  tensor2=Unfold(tensor,size(tensor),2);
  tensor3=Unfold(tensor,size(tensor),3);
  [U1,s1,V1] = svd(tensor1,'econ') ;
  [U2,s2,V2] = svd(tensor2,'econ') ;
  [U3,s3,V3] = svd(tensor3,'econ') ;
  k1=max(size(diag(s1)));
  per1=diag(s1)/sum(diag(s1));
  for k=1:k1
  if  sum(per1(1:k,1))>=percentage
       rankmax(1)=k;
  break;
  end
  end
  k2=max(size(diag(s2)));
  per2=diag(s2)/sum(diag(s2));
  for k=1:k2
  if  sum(per2(1:k,1))>=percentage
      rankmax(2)=k;
  break;
  end
  end
  k3=max(size(diag(s3)));
  per3=diag(s3)/sum(diag(s3));
  for k=1:k3
  if  sum(per3(1:k,1))>=percentage
      rankmax(3)=k;
  break;
  end
  end
  %�˷����ļ�Ȩֵ�ٷֱ�
  rank=[rankmax(1),rankmax(2),rankmax(3)]
  B=100*rank/sum(rank);
  alpha = [10^B(1,1),10^B(1,2),10^B(1,3)]/sum([10^B(1,1),10^B(1,2),10^B(1,3)]);