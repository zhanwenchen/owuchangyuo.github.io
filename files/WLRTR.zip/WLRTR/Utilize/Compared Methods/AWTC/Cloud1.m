clear all;
addpath('E:\TensorCompletion/');
addpath('E:\TensorCompletion\mylib/');
img1=double(imread('\4.png'));
img2=double(imread('\2.png'));
D=ones(240,240,6);
D(:,:,1:3)=img1(1:240,1:240,:);
D(:,:,4:6)=img2(1:240,1:240,:);
d=D(:,:,1)+D(:,:,2)+D(:,:,3);
o=ones(size(D,1),size(D,2),2);o(:,:,1)=d;
A=ones(240,240,2);
C=ones(240,240,3);

omega=(D>0);
for i=1:3
I1=uint8(D(:,:,i));
I2=uint8(D(:,:,i+3));
A(:,:,1)=I1;A(:,:,2)=I2;
%���Omage
Omega=(o>0);
alpha=CalculateAlpha(A,0.99);%ȡSVD�ֽ��ռ75%������ֵ����
%alpha=[1e-2,1e-2,1]/sum([1e-2,1e-2,1])
T=A;
%����������
maxIter = 500;
%������ֵ
epsilon = 1e-7;
% "X" returns the estimation, 

%ִ��ֱ��ͼ���⻯
%I2=histeq(I2,hgram1);
%A(:,:,1)=I1;A(:,:,2)=I2;
% "errList" returns the list of the relative difference of outputs of two neighbor iterations 
%% High Accuracy LRTC (solve the original problem, HaLRTC algorithm in the paper)
rho = 1e-4;  
[X_H, errList_H] = HaLRTC(...
    T, ...                       % a tensor whose elements in Omega are used for estimating missing value
    Omega,...               % the index set indicating the obeserved elements
    alpha,...                  % the coefficient of the objective function, i.e., \|X\|_* := \alpha_i \|X_{i(i)}\|_* 
    rho,...                      % the initial value of the parameter; it should be small enough  
    maxIter,...               % the maximum iterations
    epsilon...                 % the tolerance of the relative difference of outputs of two neighbor iterations 
    );
C(:,:,i)=X_H(:,:,1);
end

figure;
imshow(uint8(C),[]);
%imshow(uint8(X_H(:,:,2)))
