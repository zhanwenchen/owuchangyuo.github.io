clear all;
% clear
% addpath('H:\TensorCompletion\mylib/');
% addpath('E:\TensorCompletion/');addpath('E:\TensorCompletion\mylib/');
% [image,p,t]=freadenvi('C:\Users\jean\Desktop\envi');
[image,p,t]=freadenvi('\envi');
D=image(423:782,1266:1625,1:9);A=ones(180,180,4);B=ones(360,360,4);F=ones(360,360,4);

%��һ��
for m=1:9
BW1=D(:,:,m);
max_BW=max(max(BW1));  % �������ֵ
min_BW=min(min(BW1));   % ��С����ֵ
BW_normal_one=double(255.*((BW1-min_BW)/(max_BW-min_BW))); % ��һ������
D(:,:,m)=BW_normal_one;
end
for i=1:2
    for j=1:2
A(:,:,1)=D(180*(i-1)+1:180*i,180*(j-1)+1:180*j,1);
A(:,:,2)=D(180*(i-1)+1:180*i,180*(j-1)+1:180*j,2);
A(:,:,3)=D(180*(i-1)+1:180*i,180*(j-1)+1:180*j,5);
A(:,:,4)=D(180*(i-1)+1:180*i,180*(j-1)+1:180*j,7);
%���ý�������
for k=1:4
    for m=1:10
    A(:,16*m+4*(k-1):16*m+4*k-1,k)=0;
    end
end
F(180*(i-1)+1:180*i,180*(j-1)+1:180*j,:)=A;
%���Omage
Omega =(A>0);
T=A;
%�˷����ļ�Ȩֵ
alpha=CalculateAlpha(A,0.95);%ȡSVD�ֽ��ռ75%������ֵ����
%����������
maxIter = 500;
%������ֵ
epsilon = 1e-7;
% "X" returns the estimation, 
% "errList" returns the list of the relative difference of outputs of two neighbor iterations 
%% High Accuracy LRTC (solve the original problem, HaLRTC algorithm in the paper)
rho = 1e-6;  
[X_H, errList_H] = HaLRTC(...
    T, ...                       % a tensor whose elements in Omega are used for estimating missing value
    Omega,...               % the index set indicating the obeserved elements
    alpha,...                  % the coefficient of the objective function, i.e., \|X\|_* := \alpha_i \|X_{i(i)}\|_* 
    rho,...                      % the initial value of the parameter; it should be small enough  
    maxIter,...               % the maximum iterations
    epsilon...                 % the tolerance of the relative difference of outputs of two neighbor iterations 
    );
B(180*(i-1)+1:180*i,180*(j-1)+1:180*j,:)=X_H;
    end
end

figure;
imshow(uint8(B(:,:,3)));
figure;
imshow(uint8(F(:,:,3)));