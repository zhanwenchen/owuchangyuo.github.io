clear all;
addpath('E:\TensorCompletion/');addpath('E:\TensorCompletion\mylib/');
% [image,p,t]=freadenvi('\envi');
 load('G:\My paper\2018TIP--Hyperspectral Image Restoration--Where Does the Low-Rank Property Exist\Data\MatUint8\balloons_msUint8.mat')
image = O_ImgUint8;

D=image(1:360,1:360,1:9);
A=ones(10,10,5);B=ones(10,10,5);F=ones(360,360,5);x=ones(360,360,5);M=ones(90,90,5);N=ones(360,360,5);

%��һ��
for m=1:9
BW1=D(:,:,m);
max_BW=max(max(BW1));  % �������ֵ
min_BW=min(min(BW1));   % ��С����ֵ
BW_normal_one=double(256.*((BW1-min_BW)/(max_BW-min_BW))); % ��һ������
D(:,:,m)=BW_normal_one;
end
F(:,:,1)=D(:,:,1);
F(:,:,2)=D(:,:,2);
F(:,:,3)=D(:,:,6);
F(:,:,4)=D(:,:,5);
F(:,:,5)=D(:,:,7);
%���Omage
omega =(F>0);
%����������
maxIter = 500;
%������ֵ
epsilon = 1e-7;
% "X" returns the estimation, ��ʼ��X
for i=1:36
    for j=1:36
      A=F(10*(i-1)+1:10*i,10*(j-1)+1:10*j,:);
      B=A;
      for k=1:size(F,3)
      t1=A(:,:,k);
      o1=omega(10*(i-1)+1:10*i,10*(j-1)+1:10*j,k);
      x1=t1;
      x1(logical(1-o1))=mean(t1(o1));
      B(:,:,k)=x1;    
      end
      x(10*(i-1)+1:10*i,10*(j-1)+1:10*j,:)=B;
    end
end

for i=1:4
    for j=1:4
M=F(90*(i-1)+1:90*i,90*(j-1)+1:90*j,:);
%���Omage
Omega =(M>0);
%�˷����ļ�Ȩֵ
alpha=CalculateAlpha(M,0.95);%ȡSVD�ֽ��ռ75%������ֵ����
T=M;
%����������
maxIter = 500;
%������ֵ
epsilon = 1e-7;
% "X" returns the estimation, 
X=x(90*(i-1)+1:90*i,90*(j-1)+1:90*j,:);
% "errList" returns the list of the relative difference of outputs of two neighbor iterations 
%% High Accuracy LRTC (solve the original problem, HaLRTC algorithm in the paper)
rho = 1e-4 ;  
[X_H, errList_H] = HaLRTC(...
    T, ...                       % a tensor whose elements in Omega are used for estimating missing value
    Omega,...               % the index set indicating the obeserved elements
    alpha,...                  % the coefficient of the objective function, i.e., \|X\|_* := \alpha_i \|X_{i(i)}\|_* 
    rho,...                      % the initial value of the parameter; it should be small enough  
    maxIter,...               % the maximum iterations
    epsilon,...                 % the tolerance of the relative difference of outputs of two neighbor iterations 
    X...
    );
N(90*(i-1)+1:90*i,90*(j-1)+1:90*j,:)=X_H;
    end
end
figure('units','normalized','outerposition',[0 0 1 1]);
% figure;
% set(0, 'DefaultFigurePosition', [0, 0, 2000, 1000]);
subplot(2,4,1);
imshow(uint8(F(:,:,3)));
title('Original ban6');
subplot(2,4,2);
imshow(uint8(F(:,:,2)));
title(' band2');
subplot(2,4,3);
imshow(uint8(N(:,:,3)));
title('Recovery band6');