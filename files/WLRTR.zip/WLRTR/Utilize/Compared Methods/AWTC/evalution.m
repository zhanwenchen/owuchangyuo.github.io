
% [image,p,t]=freadenvi('\Dcmall');
% % [image,p,t]=freadenvi('\ab');
% R=image;
% X_H=freadenvi('\simulateddata2_SAMNLTV');

[image,p,t]=freadenvi('\Dcmall');
R=image;
X_H=freadenvi('\Dcmallnoisy50%_MCA');

% [m,n,b]=size(R);
E=ones(307,280);
csnr=ones(60,1);
simr=ones(60,1);
for m=1:60
E=R(:,:,m);
max_E=max(max(E));  % �������ֵ
min_E=min(min(E));   % ��С����ֵ
E=double(255.*((E-min_E)/(max_E-min_E))); % ��һ������
ReferBuffer=E;
UnReferBuffer=X_H(:,:,m);
lHeight=307;
lWidth=280;
csnr(m,1) = PSNR(ReferBuffer,UnReferBuffer,lHeight,lWidth);
simr(m,1) = ssim(ReferBuffer,UnReferBuffer);
end
mpsnr=mean(csnr);
mssim=mean(simr);