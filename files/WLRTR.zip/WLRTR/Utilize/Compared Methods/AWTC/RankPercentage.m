%clc;
clear all;
addpath('E:\TensorCompletion/');addpath('E:\TensorCompletion\mylib/');
[image,p,t]=freadenvi('C:\Users\jean\Desktop\envi');
A=image(423:783,1266:1626,1:7);
%���Omage
Omega =(A>-1);
%��һ��
for m=1:7
BW1=A(:,:,m);
max_BW=max(max(BW1));  % �������ֵ
min_BW=min(min(BW1));   % ��С����ֵ
BW_normal_one=double(256.*((BW1-min_BW)/(max_BW-min_BW))); % ��һ������
A(:,:,m)=BW_normal_one;
end
T=A;
rankmax = [1, 1, 1];%��ʼ��
S1=Unfold(A,size(A),1);
S2=Unfold(A,size(A),2);
S3=Unfold(A,size(A),3);
[U1,s1,V1] = svd(S1,'econ') ;
[U2,s2,V2] = svd(S2,'econ') ; 
[U3,s3,V3] = svd(S3,'econ') ; 
k1=max(size(diag(s1)));
per1=diag(s1)/sum(diag(s1));
for k=1:k1
    if sum(per1(1:k,1))>=0.80
        rankmax(1)=k;
        break;
    end
end
k2=max(size(diag(s2)));
per2=diag(s2)/sum(diag(s2));
for k=1:k2
    if sum(per2(1:k,1))>=0.80
        rankmax(2)=k;
        break;
    end
end
k3=max(size(diag(s3)));
per3=diag(s3)/sum(diag(s3));
for k=1:k3
    if sum(per3(1:k,1))>=0.80
        rankmax(3)=k;
        break;
    end
end
%�˷����ļ�Ȩֵ�ٷֱ�
rank=[rankmax(1)/k1,rankmax(2)/k2,rankmax(3)/k3]/(rankmax(1)/k1+rankmax(2)/k2+rankmax(3)/k3);
B=100*rank/sum(rank);
%�˷����ļ�Ȩֵ
alpha = [0.1^B(1,1),0.1^B(1,2),0.1^B(1,3)]/sum([0.1^B(1,1),0.1^B(1,2),0.1^B(1,3)]);
%����������
maxIter = 500;
%������ֵ
epsilon = 1e-7;
% "X" returns the estimation, 
% "errList" returns the list of the relative difference of outputs of two neighbor iterations 

%% High Accuracy LRTC (solve the original problem, HaLRTC algorithm in the paper)
rho = 1e-6;
[X_H, errList_H] = HaLRTC(...
    T, ...                       % a tensor whose elements in Omega are used for estimating missing value
    Omega,...               % the index set indicating the obeserved elements
    alpha,...                  % the coefficient of the objective function, i.e., \|X\|_* := \alpha_i \|X_{i(i)}\|_* 
    rho,...                      % the initial value of the parameter; it should be small enough  
    maxIter,...               % the maximum iterations
    epsilon...                 % the tolerance of the relative difference of outputs of two neighbor iterations 
    );
 figure('units','normalized','outerposition',[0 0 1 1]);
% figure;
% set(0, 'DefaultFigurePosition', [0, 0, 2000, 1000]);
subplot(2,2,1);
imshow(T(:,:,6),[]);
title('Original');
subplot(2,2,2);
imshow(Omega(:,:,6));
title('Missing Values');
subplot(2,2,3);
imshow(X_H(:,:,6),[]);
title('HaLRTC');
subplot(2,2,4);
imshow(A(:,:,5),[]);
title('����7');
