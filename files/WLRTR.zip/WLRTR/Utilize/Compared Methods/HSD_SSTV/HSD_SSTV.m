function [f out params] = HSD_SSTV(utrue,g,H,params)
out.NSDE = [];
out.PSNR = [];
out.SSIM = [];
out.FunctionValue = [];% Function Value
out.betas = [];

[row,col,frames] = size(g);
f = g;
% initial outputs and inputs
alpha = params.alpha;

% �ͷ��������·���2��
% gamma = params.gamma;
% alpha1 = params.alpha1;

lambda1 = zeros(size(g));
lambda2 = lambda1;
lambda3 = lambda1;
tao     = lambda1;

%%%
mux = params.mu(1);
muy = params.mu(2);
mub = params.mu(3);
template_b= zeros(1,1,2);
template_b(:,:,1) = 1;
template_b(:,:,2) = -1;
[m,n,frame] = size(g);
Dx = psf2otf([1 -1],[m,n,frame]);
Dy = psf2otf([1;-1],[m,n,frame]);
Db = psf2otf(template_b,[m,n,frame]);
Dx_conj = conj(Dx);
Dy_conj = conj(Dy);
Db_conj = conj(Db);
Fh = psf2otf(H,[m,n,frame]);
Fh_conj = conj(Fh);


% get stop conditions
maxIter = params.maxIter;
fvTol = params.fvTol;

%% ��������
Dt = @(X,Y,Z) Dive(X,Y,Z, params.mu);
ux = zeros(row, col, frames);
uy = zeros(row, col, frames);
ub = zeros(row, col, frames);

% Main loop
loop = 0;
stopFlag = 0;
FunctionValue = 0;
% �ͷ��������·���2��
% enorm = 0;
while ~stopFlag
    loop = loop + 1;
    f_pre = f;
    FunctionValue_pre = FunctionValue;
    % �ͷ��������·���2��
    % enorm_old = enorm;
    ux_old = ux;
    uy_old = uy;
    ub_old = ub;

    
    % update auxiliaries
    Ff = fftn(f);
    tempx = mux*real(ifftn( Dx.*Ff )) + lambda1./params.beta;
    tempy = muy*real(ifftn( Dy.*Ff )) + lambda2./params.beta;
    tempb = mub*real(ifftn( Db.*Ff )) + lambda3./params.beta;
    temp  = sqrt(tempx.^2 + tempy.^2 + tempb.^2);
    temp(temp == 0) = 1;
    temp  = max(temp - alpha/params.beta, 0)./temp;
    ux = temp.*tempx;
    uy = temp.*tempy;
    ub = temp.*tempb;
    v  = max(tao/params.beta + f, 0);
    
    % update image f
    nmr = Fh_conj.*fftn(g) + mux*Dx_conj.*fftn(params.beta*ux - lambda1) +  muy*Dy_conj.*fftn(params.beta*uy - lambda2) + mub*Db_conj.*fftn(params.beta*ub - lambda3) ...
          + fftn(params.beta*v - tao);
    dnm = abs(Fh).^2 + params.beta*(abs(mux*Dx).^2 + abs(muy*Dy).^2 + abs(mub*Db).^2) + params.beta;
    Ff = nmr./dnm;
    
    f = real(ifftn(Ff));
    
    % update multipliers
    dxf = real(ifftn(mux*Dx.*Ff));
    dyf = real(ifftn(muy*Dy.*Ff));
    dbf = real(ifftn(mub*Db.*Ff));
    lambda1 = lambda1 - params.beta*(ux - dxf);
    lambda2 = lambda2 - params.beta*(uy - dyf);
    lambda3 = lambda3 - params.beta*(ub - dbf);
    tao = tao - params.beta*(v - f);
    

     %%%������Ӧ�������򻯲���
    hf = real(ifftn(Fh.*Ff));
    rnorm = sqrt(norm(dxf(:),'fro').^2 + norm(dyf(:),'fro').^2 +  norm(dbf(:),'fro').^2);
    
    params.alpha =  ( params.sigma - 1 )*norm( hf(:) - g(:),2 ).^2   /  (2* rnorm);
    
    %%% ���³ͷ�����
    %% ���� 1
%     params.beta = 1*10^3*params.alpha;
    %% ���� 2
    %enorm = sqrt( (ux-dxf).^2 + (uy-dyf).^2 + (ub-dbf).^2);
    %if enorm >= alpha1*enorm_old
    %    params.beta = gamma*params.beta;
    %end
    
    %% ���� 3
    rrr = sqrt( (ux-dxf).^2 + (uy-dyf).^2 + (ub-dbf).^2);   % ||Df - u||_2
    sss = -params.beta * Dt(ux - ux_old,uy - uy_old,ub - ub_old); 
    if sum(rrr(:)) >= 10*norm(sss(:),'fro') 
       params.beta = 2*params.beta;
    elseif norm(sss(:),'fro') >= 10*sum(rrr(:)) 
        params.beta = params.beta/2;
    end
    out.betas = [out.betas params.beta];
    
    % caculate indices
    % nsde
    error = norm(f(:)-f_pre(:),'fro')/norm(f(:),'fro');
    out.NSDE = [out.NSDE error];
    % Mean PSNR
    for i=1:size(f,3)
    psnr_i(i) = psnr(utrue(:,:,i),f(:,:,i));
    end
    out.PSNR = [out.PSNR mean(psnr_i)];
    % Mean SSIM
    for i=1:size(f,3)
    [MSSIM,ssim_map] = ssim_index(utrue(:,:,i),f(:,:,i));
    MSSIM_i(i) = MSSIM;
    end
    out.SSIM = [out.SSIM; mean(MSSIM_i)];
    
    % function value
    FunctionValue = calculateFunctionValue(f,g,H,params);
    out.FunctionValue = [out.FunctionValue  FunctionValue];
    FunctionValueTol = abs(FunctionValue_pre-FunctionValue)/FunctionValue;
%     
%     
%     %%%  show results in real time
%     % print info
%     fprintf('loop:%d,  nsde:%.4f  mpsnr:%.4f  FunctionValueTol:%.5f\n',loop,error,mean(psnr_i),FunctionValueTol);
%     % plot imgs
%     figure(1),subplot(242),imshow(f(:,:,params.showFrame));
%     title(sprintf('Restored7 PSNR:%.4f',psnr_i(params.showFrame)),'fontsize',14,'fontname','Times New Roman');axis off;
%     figure(1),subplot(243),imshow(f(:,:,1));
%     title(sprintf('Restored1 PSNR:%.4f',psnr_i(1)),'fontsize',14,'fontname','Times New Roman');axis off;
%     
%     figure(1),subplot(244),plot(1:length(out.FunctionValue),out.FunctionValue,'r--',1:length(out.FunctionValue),out.FunctionValue,'r*','MarkerFace','r','LineWidth',1);
%     % title(sprintf('Function Value Curve %.4f',FunctionValue),'fontsize',12,'fontname','Times New Roman');
%     xlabel('Iterations','fontsize',14,'fontname','Times New Roman');
%     ylabel('Objective function','fontsize',14,'fontname','Times New Roman');
% %     set(gca,'fontsize',14,'fontname','Times New Roman');
%     axis square;
%     
%     figure(1),subplot(245),plot(1:length(out.PSNR),out.PSNR,'--b',1:length(out.PSNR),out.PSNR,'+b','MarkerFace','b','LineWidth',1);
%     % title('PSNR Curve','fontsize',12,'fontname','Times New Roman');
%     xlabel('Iterations','fontsize',14,'fontname','Times New Roman');
%     ylabel('MPSNR(dB)','fontsize',14,'fontname','Times New Roman');
% %     set(gca,'fontsize',14,'fontname','Times New Roman');
%     axis square;
%         
%     figure(1),subplot(246),plot(1:length(out.SSIM),out.SSIM,'--b',1:length(out.SSIM),out.SSIM,'ob','MarkerFace','g','LineWidth',1);
%     % title('PSNR Curve','fontsize',12,'fontname','Times New Roman');
%     xlabel('Iterations','fontsize',14,'fontname','Times New Roman');
%     ylabel('MSSIM','fontsize',14,'fontname','Times New Roman');
% %     set(gca,'fontsize',14,'fontname','Times New Roman');
%     axis square;
%     
%     figure(1),subplot(247),plot(1:length(out.betas),out.betas,'--k');
%     
%     
    if FunctionValueTol < fvTol
        stopFlag = 1;
        fprintf('Algorithm converges at %d\n',loop);
        fprintf('Converge according to Function Value`s relative change\n');
    elseif loop >= maxIter
        stopFlag = 2;
        fprintf('Maxium Iterate number is reached!\n');
    end
end
params.iter = loop;
end


%% calculate Function Value
% uΪ���Ƶģ�gΪ�˻�
function FunctionValue = calculateFunctionValue(u,g,H,params)
% construct spectrum template
template_spectrum = zeros(1,1,2);
template_spectrum(:,:,1) = 1;
template_spectrum(:,:,2) = -1;

% time-frequency transform of template 
[m,n,frame] = size(g);
Fdx = psf2otf([1 -1],[m,n,frame]);
Fdy = psf2otf([1;-1],[m,n,frame]);
Fdb = psf2otf(template_spectrum,[m,n,frame]);
Fh = psf2otf(H,[m,n,frame]);
Fu = fftn(u);
hu = ifftn(Fh.*Fu);
dxu = ifftn(Fdx.*Fu);
dyu = ifftn(Fdy.*Fu);
dbu = ifftn(Fdb.*Fu);
% FunctionValue = 1/2*norm( hu(:)- g(:), 2).^2 + params.alpha*sqrt(norm(dxu(:),1) + norm(dyu(:),1) + norm(dbu(:),1));
FunctionValue = 1/2*norm( hu(:)- g(:), 2).^2 + params.alpha*sum(sqrt(params.mu(1)*dxu(:).^2 + params.mu(2)*dyu(:).^2 + params.mu(3)*dbu(:).^2));
end

function DtXYZ = Dive(X,Y,Z, beta)
frames = size(X, 3);
DtXYZ = [X(:,end,:) - X(:, 1,:), -diff(X,1,2)];
DtXYZ = beta(1)*DtXYZ + beta(2)*[Y(end,:,:) - Y(1, :,:); -diff(Y,1,1)];
Tmp(:,:,1) = Z(:,:,end) - Z(:,:,1);
Tmp(:,:,2:frames) = -diff(Z,1,3);
DtXYZ = DtXYZ + beta(3)*Tmp;
end