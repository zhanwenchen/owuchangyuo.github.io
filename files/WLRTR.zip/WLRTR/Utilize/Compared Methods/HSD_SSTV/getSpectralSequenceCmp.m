function getSpectralSequenceCmp(resultPath,g,u,utrue,u_tv)
% ------------------------ initial parameters -----------------------------
out1.pointSeq1 = [];
out1.pointSeq2 = [];
out1.pointSeq3 = [];
out1.pointSeq4 = [];

out2.pointSeq1 = [];
out2.pointSeq2 = [];
out2.pointSeq3 = [];
out2.pointSeq4 = [];

out3.pointSeq1 = [];
out3.pointSeq2 = [];
out3.pointSeq3 = [];
out3.pointSeq4 = [];

out3.lineSeq1 = [];
out3.lineSeq2 = [];
out3.lineSeq3 = [];
out3.lineSeq4 = [];
lineLength = size(g,2);
lineRow = 30;cmpBand = 2;
point_x1 = lineRow;
point_y1 = 205;
point_x2 = lineRow;
point_y2 = 73;%62,158,26,200,222,139,120,149,225~236,96,37,55,236,241
point_x3 = lineRow;
point_y3 = 159;%73,159 205
% ---------- get specific pixels and cutting lines along spectral ---------
for i = 1:size(g,3)
    % point and line sequences of clean image
    input1 = utrue(:,:,i);
    out1.pointSeq1 = [out1.pointSeq1 input1(point_x1,point_y1)];
    out2.pointSeq1 = [out2.pointSeq1 input1(point_x2,point_y2)];out3.pointSeq1 = [out3.pointSeq1 input1(point_x3,point_y3)];
    out3.lineSeq1(i,1:lineLength) = input1(lineRow,1:lineLength);
    % point and line sequences of degraded image
    input2 = g(:,:,i);
    out1.pointSeq2 = [out1.pointSeq2 input2(point_x1,point_y1)];
    out2.pointSeq2 = [out2.pointSeq2 input2(point_x2,point_y2)];out3.pointSeq2 = [out3.pointSeq2 input2(point_x3,point_y3)];
    out3.lineSeq2(i,1:lineLength) = input2(lineRow,1:lineLength);
    % point and line sequences of restored image
    input3 = u(:,:,i);
    out1.pointSeq3 = [out1.pointSeq3 input3(point_x1,point_y1)];
    out2.pointSeq3 = [out2.pointSeq3 input3(point_x2,point_y2)];out3.pointSeq3 = [out3.pointSeq3 input3(point_x3,point_y3)];
    out3.lineSeq3(i,1:lineLength) = input3(lineRow,1:lineLength);
    % point and line sequences of BTV resoted image
    input4 = u_tv(:,:,i);
    out1.pointSeq4 = [out1.pointSeq4 input4(point_x1,point_y1)];
    out2.pointSeq4 = [out2.pointSeq4 input4(point_x2,point_y2)];out3.pointSeq4 = [out3.pointSeq4 input4(point_x3,point_y3)];
    out3.lineSeq4(i,1:lineLength) = input4(lineRow,1:lineLength);
end




% 1:draw and save cutting lines along spectral ----------------------------
set(0,'DefaultAxesColorOrder',[1 0 0;[0  0.7  0.14];0 0 1],...
      'DefaultAxesLineStyleOrder','-|--|-.')
 LineWidth = 1.3;
for i = 1:size(g,3)
    % clean
    line = out3.lineSeq1(i,:);hold all;
    figure(11),p=plot(1:length(line),line);ylim([0,0.7]);
%     title('Original (9 frames)  Cutting Lines Along Spectral');
    xlabel('Columns','fontsize',20,'fontname','Times New Roman','FontWeight','bold');
    ylabel('Reflectance','fontsize',20,'fontname','Times New Roman','FontWeight','bold');
    set(gca,'fontsize',18,'YGrid','on');set(p,'LineWidth',LineWidth)
    axis square
    
    % degraded
    line = out3.lineSeq2(i,:);hold all;
    figure(12),p=plot(1:length(line),line);ylim([0,0.7]);
%     title('Degraded (9 frames)  Cutting Lines Along Spectral');
    xlabel('Columns','fontsize',20,'fontname','Times New Roman','FontWeight','bold');
    ylabel('Reflectance','fontsize',20,'fontname','Times New Roman','FontWeight','bold');
    set(gca,'fontsize',18,'YGrid','on');set(p,'LineWidth',LineWidth)
    axis square
    
    % restored
    line = out3.lineSeq3(i,:);hold all;
    figure(13),p=plot(1:length(line),line);ylim([0,0.7]);
%     title('Restored (9 frames)  Cutting Lines Along Spectral');
    xlabel('Columns','fontsize',20,'fontname','Times New Roman','FontWeight','bold');
    ylabel('Reflectance','fontsize',20,'fontname','Times New Roman','FontWeight','bold');
    set(gca,'fontsize',18,'YGrid','on');set(p,'LineWidth',LineWidth)
    axis square
    
    % BTV restored
    line = out3.lineSeq4(i,:);hold all;
    figure(17),p=plot(1:length(line),line);ylim([0,0.7]);
%     title('BTV Restored (9 frames)  Cutting Lines Along Spectral');
    xlabel('Columns','fontsize',20,'fontname','Times New Roman','FontWeight','bold');
    ylabel('Reflectance','fontsize',20,'fontname','Times New Roman','FontWeight','bold');
    set(gca,'fontsize',18,'YGrid','on');set(p,'LineWidth',LineWidth)
    axis square
end

%ylim([0 1]);%text(62,0.5333,' \leftarrow x:62,y:0.5333','fontsize',12,'Color','red');
figure(11),l1=legend('band1','band2','band3','band4','band5','band6','band7');
set(l1,'fontsize',12,'TextColor',[.3,.2,.1],'fontsize',13,'fontname','Times New Roman','FontWeight','bold','Location','SouthEastOutside');
figure(12),l2=legend('band1','band2','band3','band4','band5','band6','band7');
set(l2,'fontsize',12,'TextColor',[.3,.2,.1],'fontsize',13,'fontname','Times New Roman','FontWeight','bold','Location','SouthEastOutside');
figure(13),l3=legend('band1','band2','band3','band4','band5','band6','band7');
set(l3,'fontsize',12,'TextColor',[.3,.2,.1],'fontsize',13,'fontname','Times New Roman','FontWeight','bold','Location','SouthEastOutside');
figure(17),l4=legend('band1','band2','band3','band4','band5','band6','band7');
set(l4,'fontsize',12,'TextColor',[.3,.2,.1],'fontsize',13,'fontname','Times New Roman','FontWeight','bold','Location','SouthEastOutside');


% save the figures
print(figure(11),[resultPath '/Cutting Lines Along Spectral_true.eps'],'-depsc2','-r600');
saveas(figure(11),[resultPath '/Cutting Lines Along Spectral_original.tiff']);
saveas(figure(11),[resultPath '/Cutting Lines Along Spectral_original.fig']);
print(figure(12),[resultPath '/Cutting Lines Along Spectral_obs.eps'],'-depsc2','-r600');
saveas(figure(12),[resultPath '/Cutting Lines Along Spectral_degrade.tiff']);
saveas(figure(12),[resultPath '/Cutting Lines Along Spectral_degrade.fig']);
print(figure(13),[resultPath '/Cutting Lines Along Spectral_res.eps'],'-depsc2','-r600');
saveas(figure(13),[resultPath '/Cutting Lines Along Spectral_restore.tiff']);
saveas(figure(13),[resultPath '/Cutting Lines Along Spectral_restore.fig']);
print(figure(17),[resultPath '/Cutting Lines Along Spectral_btv.eps'],'-depsc2','-r600');
saveas(figure(17),[resultPath '/Cutting Lines Along Spectral_btv.tiff']);
saveas(figure(17),[resultPath '/Cutting Lines Along Spectral_btv.fig']);



% 2��draw and save pixels along spectral ----------------------------------
figure(14),
p1 = plot(1:length(out1.pointSeq1),out1.pointSeq1,'-rs');
set(p1,'LineWidth',2,'MarkerEdgeColor','r','MarkerFaceColor','r');
hold on;

p2 = plot(1:length(out1.pointSeq2),out1.pointSeq2,'-');
set(p2,'LineWidth',2,'MarkerEdgeColor',[0  0.5  0.14],'MarkerFaceColor',[0  0.5  0.14],'color',[0  0.5  0.14]);
hold on;

p3 = plot(1:length(out1.pointSeq3),out1.pointSeq3,'-b<');
set(p3,'LineWidth',2,'MarkerEdgeColor','b','MarkerFaceColor','b');
hold on;

p31 = plot(1:length(out1.pointSeq4),out1.pointSeq4,'-b+');
set(p31,'LineWidth',2,'MarkerEdgeColor',[0  0.75  0.75],'MarkerFaceColor',[0  0.75  0.75],'color',[0  0.75  0.75]);
hold on;

p4 = plot(1:length(out2.pointSeq1),out2.pointSeq1,'-.rs');
set(p4,'LineWidth',2,'MarkerEdgeColor','r','MarkerFaceColor','r');
hold on;

p5 = plot(1:length(out2.pointSeq2),out2.pointSeq2,'-.');
set(p5,'LineWidth',2,'MarkerEdgeColor',[0  0.5  0.14],'MarkerFaceColor',[0  0.5  0.14],'color',[0  0.5  0.14]);
hold on;

p6 = plot(1:length(out2.pointSeq3),out2.pointSeq3,'-.b<');
set(p6,'LineWidth',2,'MarkerEdgeColor','b','MarkerFaceColor','b');
hold on;

p61 = plot(1:length(out2.pointSeq4),out2.pointSeq4,'-.b+');
set(p61,'LineWidth',2,'MarkerEdgeColor',[0  0.75  0.75],'MarkerFaceColor',[0  0.75  0.75],'color',[0  0.75  0.75]);
hold on;

p7 = plot(1:length(out3.pointSeq1),out3.pointSeq1,'--rs');
set(p7,'LineWidth',2,'MarkerEdgeColor','r','MarkerFaceColor','r');
hold on;

p8 = plot(1:length(out3.pointSeq2),out3.pointSeq2,'--');
set(p8,'LineWidth',2,'MarkerEdgeColor',[0  0.5  0.14],'MarkerFaceColor',[0  0.5  0.14],'color',[0  0.5  0.14]);
hold on;

p9 = plot(1:length(out3.pointSeq3),out3.pointSeq3,'--b<');
set(p9,'LineWidth',2,'MarkerEdgeColor','b','MarkerFaceColor','b');
hold on;

p91 = plot(1:length(out3.pointSeq4),out3.pointSeq4,'--b+');
set(p91,'LineWidth',2,'MarkerEdgeColor',[0  0.75  0.75],'MarkerFaceColor',[0  0.75  0.75],'color',[0  0.75  0.75]);
hold on;

legen1 = legend([p1 p4 p7 p2 p5 p8 p31 p61 p91 p3 p6 p9],'original1','original2','original3','degraded1','degraded2','degraded3','TV-BDSB1','TV-BDSB2','TV-BDSB3','SSTV1','SSTV2','SSTV3');
set(legen1,'TextColor',[.3,.2,.1],'fontsize',13,'fontname','Times New Roman','FontWeight','bold','Location','SouthEastOutside');
xlabel('Band number','fontsize',20,'fontname','Times New Roman','FontWeight','bold');set(gca,'XTick',1:1:6,'fontsize',18);
ylabel('Reflectance','fontsize',20,'fontname','Times New Roman','FontWeight','bold');ylim([0,0.6]);
% title('Spectral profile','fontsize',14,'fontname','Times New Roman');
axis square;axis tight;
% save the figure
print(figure(14),[resultPath '/One Pixel Along Spectral.eps'],'-depsc2','-r600');
saveas(figure(14),[resultPath '/One Pixel Along Spectral.tiff']);
saveas(figure(14),[resultPath '/One Pixel Along Spectral.fig']);





% 3.1: draw the comparison of org��degraded��restored spatial cutting lines
% cmpBand = 7;
figure(15);
line = out3.lineSeq1(cmpBand,:);hold on;
figure(15),p1=plot(1:length(line),line,'-r');
set(p1,'LineWidth',1,'color','r');

line = out3.lineSeq2(cmpBand,:);hold on;
figure(15),p2=plot(1:length(line),line,'-');
set(p2,'LineWidth',1,'color',[0  0.5  0.14]);

line = out3.lineSeq3(cmpBand,:);hold on;
figure(15),p3=plot(1:length(line),line,'-b');
set(p3,'LineWidth',1);

line = out3.lineSeq4(cmpBand,:);hold on;
figure(15),p4=plot(1:length(line),line,'-');
set(p4,'LineWidth',1,'color',[0 0.75 0.75]);


xlabel('Columns','fontsize',20,'fontname','Times New Roman','FontWeight','bold');xlim([0,250]);
ylabel('Reflectance','fontsize',20,'fontname','Times New Roman','FontWeight','bold');ylim([0,0.7]);
% title('Comparison of the original,degraded and restored','fontsize',14,'fontname','Times New Roman');
axis square;
set(gca,'fontsize',18);
leg1 = legend([p1 p2 p4 p3],'original','degraded','TV-BDSB','SSTV');
set(leg1,'TextColor',[.3,.2,.1],'fontsize',13,'fontname','Times New Roman','FontWeight','bold','Location','North');

%1: draw close-up
% figure(15),drawEllipse(61,0.56,12,0.08);
% figure(15),drawEllipse(52,0.2,10,0.05);
% figure(15),drawEllipse(70,0.38,10,0.05);
% figure(15),drawEllipse(157,0.4,14,0.03);
% figure(15),drawEllipse(222,0.34,12,0.08);
% figure(15),drawEllipse(200,0.13,14,0.03);


figure(15),drawEllipse(62,0.5,10,0.05);
figure(15),drawEllipse(55,0.3,14,0.10);
% figure(15),drawEllipse(70,0.38,10,0.05);
figure(15),drawEllipse(156,0.45,14,0.03);
figure(15),drawEllipse(159,0.28,14,0.03);
figure(15),drawEllipse(201,0.08,14,0.02);
% figure(15),drawEllipse(200,0.13,14,0.03);


% %2: draw close-up  cmpBand = 4;
% figure(15),drawEllipse(26,0.11,10,0.06);
% figure(15),drawEllipse(66,0.425,12,0.08);
% % figure(15),drawEllipse(70,0.38,10,0.05);
% figure(15),drawEllipse(149,0.41,14,0.03);
% figure(15),drawEllipse(159,0.3,10,0.06);
% figure(15),drawEllipse(183,0.2,14,0.025);
% figure(15),drawEllipse(200,0.1,14,0.03);
% figure(15),drawEllipse(221,0.25,12,0.08);

% save
print(figure(15),[resultPath '/Comparison of original, degraded and restored 1.eps'],'-depsc2','-r600');
saveas(figure(15),[resultPath '/Comparison of original, degraded and restored 1.tiff']);
saveas(figure(15),[resultPath '/Comparison of original, degraded and restored 1.fig']);





% 3.2: draw the comparison of org��degraded��restored spatial cutting lines
cmpBand = 4;
figure(16),
line = out3.lineSeq1(cmpBand,:);hold on;
figure(16),p1=plot(1:length(line),line,'-r');
set(p1,'LineWidth',1);

line = out3.lineSeq2(cmpBand,:);hold on;
figure(16),p2=plot(1:length(line),line,'-');
set(p2,'LineWidth',1,'color',[0  0.5  0.14]);

line = out3.lineSeq3(cmpBand,:);hold on;
figure(16),p3=plot(1:length(line),line,'-b');
set(p3,'LineWidth',1);

line = out3.lineSeq4(cmpBand,:);hold on;
figure(16),p4=plot(1:length(line),line,'-');
set(p4,'LineWidth',1,'color',[0 0.75 0.75]);


xlabel('Columns','fontsize',20,'fontname','Times New Roman','FontWeight','bold');xlim([0,250]);
ylabel('Reflectance','fontsize',20,'fontname','Times New Roman','FontWeight','bold');ylim([0,0.7]);
% title('Comparison of the original,degraded and restored','fontsize',14,'fontname','Times New Roman');
axis square;
set(gca,'fontsize',18);
leg1 = legend([p1 p2 p4 p3],'original','degraded','TV-BDSB','SSTV');
set(leg1,'TextColor',[.3,.2,.1],'fontsize',13,'fontname','Times New Roman','FontWeight','bold','Location','North');

%2: draw close-up  cmpBand = 4;
figure(16),drawEllipse(26,0.11,10,0.06);
figure(16),drawEllipse(66,0.425,12,0.08);
figure(16),drawEllipse(149,0.41,14,0.03);
figure(16),drawEllipse(159,0.3,10,0.06);
figure(16),drawEllipse(183,0.2,14,0.025);
figure(16),drawEllipse(200,0.1,14,0.03);
figure(16),drawEllipse(221,0.25,12,0.08);

% save
print(figure(16),[resultPath '/Comparison of original, degraded and restored 2.eps'],'-depsc2','-r600');
saveas(figure(16),[resultPath '/Comparison of original, degraded and restored 2.tiff']);
saveas(figure(16),[resultPath '/Comparison of original, degraded and restored 2.fig']);
end
