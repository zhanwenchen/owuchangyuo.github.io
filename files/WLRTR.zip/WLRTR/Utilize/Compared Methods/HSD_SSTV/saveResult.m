function [resultPath paramRecordPath] = saveResult(experiType,fileName,noiseLevel,params,g,u,utrue,out)
% obsImg = java_array('java.lang.String', size(g,3));
% resImg = java_array('java.lang.String', size(u,3));

% ---------------------------- ���������� ----------------------------------
dataDir = '';
fieldNames = fieldnames(params);
field_size = size(fieldNames,1);
fields(:,:,field_size) = 0;% fields���ڱ������
dirLength = 3;% ��ʾ�����ļ��������Ĳ�������

i = 0;
while i<field_size
    i = i+1;
    fieldName = fieldNames(i);
    if ~strcmp('mu',fieldName)
       fields(:,:,i) = getfield(params,char(fieldName)); 
    end
    if i<=dirLength
        dataDir = [dataDir char(fieldName) '=' num2str(fields(:,:,i))];
    end
end



% ------------------------  �����洢����ļ���  ----------------------------
dirFlag = 0;
resultPath = ['./Results/' experiType '/' fileName '/' 'noiseLevel=' num2str(noiseLevel) '/' dataDir];
paramRecordPath = ['../Results/' experiType '/' fileName '/' 'noiseLevel=' num2str(noiseLevel)];% ��¼ÿ�Φ���FunctionValue�Ĺ�ϵ
% �жϸ��ļ����Ƿ���ڣ�������dirFlag��Ϊ1
if exist(resultPath,'dir')
    dirFlag = 1;
end
% �����������½��ļ���
if (dirFlag == 0)
    if ~mkdir(resultPath) 
        fprintf('create direct failed!!!');
        return;% ������ʧ�ܣ��򷵻�
    end;
end



% --------------------------- �������'.txt' -------------------------------
% �� *.txt; ע�⣺dataDir�ַ��������пո񣬷����޷�����.txt
txtFile = [resultPath  '/experiParameters.txt'];
fid = fopen(txtFile, 'at+');
% ����ʵ���������
i = 0;
while i<field_size
    i = i+1;
    fieldName = char(fieldNames(i));
    fprintf( fid,[fieldName '=%.8f'],fields(:,:,i));
    fprintf( fid, '\n' );
end
% �ر��ļ���
fclose( fid );



% ---------------------------- �������ͼƬ --------------------------------
frame = size(g,3);
for i = 1:frame
    % ����ͼƬ��Ӧ��PSNRָ��
    psnr_obs = psnr(utrue(:,:,i),g(:,:,i));
    psnr_res = psnr(utrue(:,:,i),u(:,:,i));
    [ssim_res,ssim_map] = ssim_index(utrue(:,:,i),u(:,:,i));
    % PNG ��ʽ
    % obsImg(i) = java.lang.String([resultPath '/obs' num2str(i) ' psnr_' num2str(psnr_obs) '.png']);
    % resImg(i) = java.lang.String([resultPath '/res' num2str(i) ' psnr_' num2str(psnr_res) 'ssim_' num2str(ssim_res) '.png']);
    
    imwrite(g(:,:,i),[resultPath '/obs' num2str(i) ' psnr_' num2str(psnr_obs) '.png']);
    imwrite(u(:,:,i),[resultPath '/res' num2str(i) ' psnr_' num2str(psnr_res) 'ssim_' num2str(ssim_res) '.png']);
    % utrue��д
    temp = utrue(:,:,i);
    temp = temp(50:140,56:236);
    figure('Name','Utrue_close-up','NumberTitle','off'); imshow(temp); axis off; %title('RL restoration');
    saveas(gcf,[resultPath '/utrue_closeup' num2str(i) '.tif']);
    print(gcf,[resultPath '/utrue_closeup' num2str(i) '.eps'],'-depsc2 ','-r300');
    close
    
    % �˻�eps ��ʽ
    figure;
%     imagesc(g(:,:,i));
%     axis image;
%     colormap(gray);
    imshow(g(:,:,i));
    axis off;%%axis equal;
    print(gcf,[resultPath '/degrade' num2str(i) ' psnr_' num2str(psnr_obs) '.eps'],'-depsc2 ','-r600');
    drawnow
    close
    % �˻���д
    temp = g(:,:,i);
    temp = temp(50:140,56:236);
    figure('Name','Degrade_close-up','NumberTitle','off'); imshow(temp); axis off; %title('RL restoration');
    saveas(gcf,[resultPath '/degrade_closeup' num2str(i) '.tif']);
    print(gcf,[resultPath '/degrade_closeup' num2str(i) '.eps'],'-depsc2 ','-r300');
    close
    
    % �ָ�eps ��ʽ
    figure;
%     imagesc(u(:,:,i));
%     axis image;
%     colormap(gray);
    imshow(u(:,:,i));
    axis off;%%axis equal;
    print(gcf,[resultPath '/res' num2str(i) ' psnr_' num2str(psnr_res) '.eps'],'-depsc2 ','-r600');
    drawnow
    close
     % �ָ���д
    temp = u(:,:,i);
    temp = temp(50:140,56:236);
    figure('Name','Res_close-up','NumberTitle','off'); imshow(temp); axis off;%title('RL restoration');
    saveas(gcf,[resultPath '/res_closeup' num2str(i) '.tif']);
    print(gcf,[resultPath '/res_closeup' num2str(i) '.eps'],'-depsc2 ','-r300');
    close
end
% imwrite(utrue,[resultPath '/utrue.png']);



% -----------------------  ����ָ��仯���� ----------------------------
fieldNames = fieldnames(out);
field_size = size(fieldNames,1);

i = 0;
while i<field_size
    i = i+1;
    fieldName = fieldNames(i);
    if strcmp(experiType,'real')&&(strcmp(char(fieldName),'PSNR')||strcmp(char(fieldName),'SSIM'))
        continue;
    end
    
    field = getfield(out,char(fieldName));
    % ��figure����ʾ�������Ա��������
    figure;
    % plot(1:length(field ),field ,'r--','LineWidth',2);
    % plot(1:length(field ),field ,'b--',1:length(field ),field ,'r*');
    plot(1:length(field ),field ,'b--','LineWidth',2);
    xlabel('Iterations','fontsize',14,'fontname','Times New Roman'); 
    ylabel(char(fieldName),'fontsize',14,'fontname','Times New Roman');
    axis square
    
    % ����һ�ݷֱ���Ϊ600��epsͼ
    print(gcf,[resultPath '/Proposed' char(fieldName) ' iterations.eps'],'-depsc2','-r600');
    % ����һ��tiffͼ���Ա���ʱ�鿴
    saveas(gcf,[resultPath '/Proposed'  char(fieldName)  ' iterations.tiff']);
    close
    % end
end