function [] = drawEllipsoid(cx,cy,a,b)
elliPointXs = -a:0.01:a;
elliPointYs(:,1) = cy+sqrt((1-elliPointXs.^2/a^2)*b^2); 
elliPointYs(:,2) = cy-sqrt((1-elliPointXs.^2/a^2)*b^2);
elliPointXs = cx+elliPointXs;
plot(elliPointXs,elliPointYs,'-.r','LineWidth',2)
end