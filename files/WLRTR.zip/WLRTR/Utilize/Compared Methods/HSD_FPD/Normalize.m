function [u,MaxVal] = Normalize(I)
u = I;


MinVal = 1e+7;
for i=1:size(I,3),
    MinVal = min(MinVal,min(min(u(:,:,i))));
end;    

u = u-MinVal;

MaxVal = 0;
for i=1:size(I,3),
    MaxVal = max(MaxVal,max(max(u(:,:,i))));
end;    
    
for i=1:size(I,3),
    a = u(:,:,i);
    %a(a<0) = 0;
    %u(:,:,i) = a;
       
    u(:,:,i) = u(:,:,i)/MaxVal;
            
end;   