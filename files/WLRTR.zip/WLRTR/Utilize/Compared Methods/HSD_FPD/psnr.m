function p = psnr(X, S)
% Peak Signal-to-noise ratio
%
% Input: X - reference image
%
%        S - image being compared
%
%        max - maximum pixel value of the image
%
% Output: p - psnr

[m n]= size(X);
maxv = max(S(:));
p = 10 * log10((maxv * maxv) / (norm(X - S, 'fro')^2 / (m*n)));
