function h = psf2D(f,paraxial,l_em,l_ex,NA,r)

% PSF computes a 2D Gaussian approximation of a Confocal Laser Scanning
% Microscope (CLSM) Point-Spread Function (PSF) for a given set of emission
% wavelengths.
% Reference:
% B. Zhang, J. Zerubia, and J. Olivo-Marin, 
% "Gaussian approximations of fluorescence microscope point-spread function
% models",
% Appl. Opt. 46, 1819-1829, 2007.
%
% Input:
% f    : pixel size
% paraxial: 1 if true, 0 if not
% l_em : l-axis range (spectral coordinate - emission wavelength)
% l_ex : excitation wavelength
% NA   : object spacerefractive index
% r    : pinhole radius
%
% Output:
% h    : 3D array. h(:,:,k) is PSF for emission wavelength l_em(k)
% sigma: gaussian parameter

%% compute physical parameters
k_ex = 2*pi/l_ex; sigma_ex = sqrt(2) / (k_ex*NA);
k_em = 2*pi./l_em; sigma_em = sqrt(2) ./ (k_em*NA);
c1 = k_ex*r*NA;
c2 = k_em*r*NA;

%% compute gaussian parameter
switch paraxial
    case 1
        num = 4*c2.*besselj(0,c2).*besselj(1,c2)-8*besselj(1,c2).^2;
        den = r^2*[besselj(0,c2).^2+besselj(1,c2).^2-1];
        frac = c1^2/r^2+num./den;
    case 0
        num = 2*sigma_em.^4 .* (exp(r^2./(2*sigma_em.^2))-1)...
            + r^2*sigma_ex.^2;
        den = sigma_ex.^2.*sigma_em.^4 .*...
            (exp(r^2./(2*sigma_em.^2))-1);
        frac = num./den;
end
sigma = sqrt(2)*frac.^(-1/2);

%% compute PSF
hsize = 7;  %ceil(max(6*sigma/f));
h = zeros(hsize,hsize,length(l_em));
for l=1:length(l_em)
    h(:,:,l) = fspecial('gaussian',hsize,sigma(l)/f);
end