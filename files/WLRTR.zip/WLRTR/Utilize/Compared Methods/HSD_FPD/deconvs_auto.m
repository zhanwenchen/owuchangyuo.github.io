function [x, P] = deconvs_auto(y,h,mu,nu,conv,regu,pos)
% DECONVS deconvolution of spectral images
% x = deconvs_3regul(y,h,mu,nu,conv,regu,pos)
% y  : N1 x N2 x L observed spectral data
% h  : P1 x P2 x L point-spread function (PSF)
% mu : spatial regularization parameter
% nu : spectral regularization parameter
% conv : convolution type
%      * 'direct' assumes the original convolution is direct, i.e.
%      y = conv2(x0,h,'full') where x0 is (N1-P1+1)x(N2-P2+1)
%      * 'circular' assumes the original convolution is circular, i.e.
%      y = real(ifft2(fft2(x0).*fft2(h))) where x0 is N1xN2
% regu : spatial regularization type : 'l2', 'l2l1_sq', 'l2l1_admm', 'l1'
% pos  : positivity constraint : 'on', 'off'
% last update : 09/06/13

%% main

% data size
N1 = size(y,1); N2 = size(y,2); L = size(y,3);
P1 = size(h,1); P2 = size(h,2);

% spatial regularization operator
laplacian = [0,-1,0;-1,4,-1;0,-1,0];
d = reshape(repmat(laplacian,1,L),3,3,L);

% spectral regularization operator
T0 = toeplitz([-1;zeros(L-2,1)],[-1 1 zeros(1,L-2)]);
E0 = sparse([T0;zeros(1,size(T0,2))]);

% positivity constraint �ͷ����� xi
switch pos
    case 'off'
        Niter_pos = 1;
    case 'on'
        Niter_pos = 10;
end
xi1 = 1; alpha = 10;  %t = -1e-6;
xi = [0 xi1*alpha.^(0:Niter_pos-1)]; %so 1st iteration without s

% l2l1 stuff
eta=10;

% ADMM stuff
rho = 1;

% auxiliary variables ��ʼ��
s = zeros(N1-P1+1,N2-P2+1,L);  %full convolution
S = zeros(N1,N2,L); %circular convolution
b=s; B=S; %'l2'�в����õ�
z=s; Z=S;
u=s; U=S;

%% fourier domain
Y = fft2(y,N1,N2);
% H = fft2(h,N1,N2); %����ֱ߽�ЧӦ
for i = 1:size(y,3)
   H(:,:,i) = psf2otf(h(:,:,i),[N1, N2]); 
end
D = fft2(d,N1,N2);
X = zeros(N1,N2,L);

% gather variables in struct variables to call other functions
variables = struct('data',Y,'psf',H,'spatial_operator',D,...
    'spectral_operator',E0,'spatial_param',mu,...
    'spectral_param',nu,'pos_vect',xi,'regul',regu,'rho',rho);

%% ��ʼ�㷨�������
switch regu
    case 'l2'
        %% deconvolution with l2 regularization
        % variables: x,s (s = auxiliary variable to enforce nonnegativity)
        for k = 1:Niter_pos %k���Ǵӵ�2�ε�����ʼ, xi(0)����ִ�е�
            %%% unconstrained minimization w.r.t. x %%%
            X = sym(variables,S,B,Z,U,k); %���� sym �Ӻ���
            xf = real(ifft2(X));
            
            %%% 'direct' convolution, crop to (N1-P1+1) x (N2-P2+1)
            x = xf(1:N1-P1+1, 1:N2-P2+1, :);
            
            %%% constrained minimization w.r.t. s %%%
            s = max(0,x); S = fft2(s,N1,N2);
        end
        
    case 'l2l1_sq'
        %% deconvolution with l2l1 regularization, SQ method
        % variables : x,s,b
        Niter_SQ = 30;
        P = zeros(Niter_pos,Niter_SQ);
        for k=1:Niter_pos
            for kSQ=1:Niter_SQ
                %%% unconstrained minimization wrt x %%%
                X = sym(variables,S,B,Z,U,k);
                xf = real(ifft2(X));
                x = xf(1:N1-P1+1,1:N2-P2+1,:);
                %%% unconstrained minimization wrt b %%%
                xdf = real(ifft2(X.*D));
                xd = xdf(1:N1-P1+1,1:N2-P2+1,:);
                b = xd-dhuber(xd,eta);
                B = fft2(b,N1,N2);
                %%% constrained minimization wrt s %%%
                s = max(0,x); S = fft2(s,N1,N2);
                %%% criterion %%%
                P(k,kSQ) = critere(X,S,Y,H,D,mu,nu,xi(k),eta,P1,P2);
            end
        end
    case 'l2l1_admm'
        %% deconvolution with l2l1 regularization, ADMM/prox method
        % variables : x,s,z,u (z = Dx, u = lagrange multipliers)
        Niter_ADMM = 30;
        P = zeros(Niter_pos,Niter_ADMM);
        for k=1:Niter_pos
            for kADMM=1:Niter_ADMM
                %%% unconstrained minimization w.r.t. x %%%
                X = sym(variables,S,B,Z,U,k);
                xf = real(ifft2(X));
                x = xf(1:N1-P1+1,1:N2-P2+1,:);
                %%% unconstrained minimization w.r.t. z %%%
                dxf = real(ifft2(D.*X));
                dx = dxf(1:N1-P1+1,1:N2-P2+1,:);
                z = prox_huber(dx+u,eta,2*rho/mu);
                Z = fft2(z,N1,N2);
                %%% constrained minimization w.r.t. s %%%
                s = max(0,x); S = fft2(s,N1,N2);
                %%% dual update w.r.t. u %%%
                u = u+dx-z; U = fft2(u,N1,N2);
                %%% criterion %%%
                P(k,kADMM) = critere(X,S,Y,H,D,mu,nu,xi(k),eta,P1,P2);
            end
        end
    case 'l1'
        %% deconvolution with l1 regularization
        % variables : x,s,z,u (z = Dx, u = lagrange multipliers)
        Niter_ADMM = 30;
        P = zeros(Niter_pos,Niter_ADMM);
        for k=1:Niter_pos
            for kADMM=1:Niter_ADMM
                %%% unconstrained minimization wrt x %%%
                X = sym(variables,S,B,Z,U,k);
                xf = real(ifft2(X));
                x = xf(1:N1-P1+1,1:N2-P2+1,:);
                %%% unconstrained minimization wrt z %%%
                dxf = real(ifft2(D.*X));
                dx = dxf(1:N1-P1+1,1:N2-P2+1,:);
                z = shrinkage(dx+u,2*rho/mu);
                Z = fft2(z,N1,N2);
                %%% constrained minimization wrt s %%%
                s = max(0,x); S = fft2(s,N1,N2);
                %%% dual update wrt u %%%
                u = u+dx-z; U = fft2(u,N1,N2);
                P(k,kADMM) = critere(X,S,Y,H,D,mu,nu,xi(k),eta,P1,P2);
            end
        end
end

% output image
switch conv
    case 'circular' % output image size is the the same as y
        x = xf;
    case 'direct' % crop to (N1-P1+1) x (N2-P2+1)
        x = xf(1:N1-P1+1,1:N2-P2+1,:);
end
end

%%========================= �Ӻ��� ======================================
%% compute spectrum at frequencies f1 and f2
function val = comp(variables,S,B,Z,U,k,f1,f2)

Y = variables.data;
L = size(Y,3);
H = variables.psf;
D = variables.spatial_operator;
E0 = variables.spectral_operator;
mu = variables.spatial_param;
nu = variables.spectral_param;
xi = variables.pos_vect;
regu = variables.regul; %��������
rho = variables.rho;

% computes spectrum at f1 and f2. squeezeɾ�������еĵ�һά��
vy = squeeze(Y(f1,f2,:));
vs = squeeze(S(f1,f2,:));
vb = squeeze(B(f1,f2,:));
vz = squeeze(Z(f1,f2,:));
vu = squeeze(U(f1,f2,:));
Dh = diag(squeeze(H(f1,f2,:)));
Dd = diag(squeeze(D(f1,f2,:)));

switch regu
    case 'l2'
        A = abs(Dh).^2 + (mu*abs(D(f1,f2))^2 + xi(k))*eye(L) + nu*(E0'*E0);
        bv = conj(Dh)*vy + xi(k)*vs;
    case 'l2l1_sq'
        A = abs(Dh).^2 ...
            + (mu/2*abs(D(f1,f2))^2 + xi(k))*eye(L) ...
            + nu*(E0'*E0);
        bv = conj(Dh)*vy+ xi(k)*vs + mu/2*conj(Dd)*vb;
    case 'l2l1_admm'
        A = abs(Dh).^2 ...
            + (rho*abs(D(f1,f2))^2 + xi(k))*eye(L) ...
            + nu*(E0'*E0);
        bv = conj(Dh)*vy + xi(k)*vs + rho*conj(Dd)*(vz-vu);
    case 'l1'
        A = abs(Dh).^2 ...
            + (rho*abs(D(f1,f2))^2 + xi(k))*eye(L) ...
            + nu*(E0'*E0);
        bv = conj(Dh)*vy + xi(k)*vs + rho*conj(Dd)*(vz-vu);
end
val = A\bv;  %A*val = bv
end

%% compute full spectrum with hermitian symmetry
function spec = sym(variables,S,B,Z,U,k)

Y = variables.data;
N1 = size(Y,1); N2 = size(Y,2); L = size(Y,3);
spec = zeros(N1,N2,L); %��ʼ��

if rem(N1,2) %����Ϊ��,��ִ��. %rem: ����������
    r1 = (N1+1)/2; r2 = r1; %old
else
    r1 = N1/2+1; r2 = r1-1;
end

if rem(N2,2)
    c1 = (N2+1)/2; c2 = c1;
else
    c1 = N2/2+1; c2 = c1-1;
end

% compute 1st row, columns 1 : c2
for col = 1:c1
    spec(1,col,:) = comp(variables,S,B,Z,U,k,1,col);
end
% compute rows 2 : ind
for row = 2:r1
    for col = 1:N2
        spec(row,col,:) = comp(variables,S,B,Z,U,k,row,col);
    end
end

% fill in spectrum
for l = 1:L
    % 1st row, columns c+1 : N
    spec(1,c1+1:N2,l) = fliplr(conj(spec(1,2:c2,l)));
    % 1st column, rows k+1 : N
    spec(r1+1:N1,1,l) = flipud(conj(spec(2:r2,1,l)));
    % rows ind+1 : M, columns 2 : N
    spec(r1+1:N1,2:N2,l) = rot90(conj(spec(2:r2,2:N2,l)),2);
end
end

%% huber fct, derivative, and proximal operator of huber and l1
function phi = huber(t,eta)
% function of huber
phi = eta*(2*abs(t)-eta);
ind_phi = abs(t)<eta;
phi(ind_phi) = t(ind_phi).^2;
end

function dphi = dhuber(t,eta)
% derivative of function of huber
dphi = 2*eta*sign(t);
ind_phi = abs(t)<eta;
dphi(ind_phi) = 2*t(ind_phi);
end

function pphi = prox_huber(t,eta,rho)
% proximal operator of the huber function
pphi = t-eta*sign(t);
ind_prox = abs(t)<(eta*(2/rho+1));
pphi(ind_prox) = t(ind_prox)/(2/rho+1);
end

function y = shrinkage(a, kappa)
% shrinkage function (proximal operator of l1)
y = max(0, a-kappa) - max(0, -a-kappa);
end

%% criterion (7) article gretsi 2013 TIP
% P(x,s,xi) = 1/2*|y-Hx|^2 + mu/2*sum(huber(Dx_i))+nu/2*|Ex|^2+xi/2*|x-s|^2
function P = critere(X,S,Y,H,D,mu,nu,xi,eta,P1,P2)
%% ����Ŀ�귺����ֵ
[N1,N2,L] = size(X);

% Calculate the data term
J0_mat = Y-X.*H;
j0_mat_f = real(ifft2(J0_mat));
j0_mat2 = j0_mat_f(1:N1-P1+1,1:N2-P2+1,:).^2;
j0 = sum(j0_mat2(:));

% regularisation spatial
DX = X.*D;
dx_f = real(ifft2(DX));
hdx = huber(dx_f(1:N1-P1+1,1:N2-P2+1,:),eta);
jREGs = sum(hdx(:));

% regularization spectral
xf = real(ifft2(X));
x = xf(1:N1-P1+1,1:N2-P2+1,:);
jREGl_mat = zeros(N1,N2,L);
for l=2:L
    jREGl_mat(:,:,l) = (x(:,:,l) - x(:,:,l-1)).^2;
end
jREGl = sum(jREGl_mat(:));

% positivity constraint term
sf = real(ifft2(S));
s = sf(1:N1-P1+1,1:N2-P2+1,:);
pPos_mat = (x-s).^2;
pPos = sum(pPos_mat(:));

% criterion
P = 1/2*j0 + mu/2*jREGs + nu/2*jREGl + xi/2*pPos;
end