% Function evaluating the response surface
function [Y_hx,Ds,Dn] = RS(y_noise,h,mu,nu,conv,regu,pos)

run = 0;
ht = (size(h,1)-1)/2;
for n=1:length(nu)
    for m=1:length(mu)
        x = deconvs_auto(y_noise,h,mu(m),nu(n),conv,regu,pos);
%         y = y_noise(ht+1:end-ht,ht+1:end-ht,:); %old
        y = y_noise; %new, û�м���
        [y_hx,Dsx,Dnx] = RS_one(x,y,h);
        Y_hx(m,n) = y_hx;
        Ds(m,n) = Dsx;
        Dn(m,n) = Dnx;
        run = run + 1;
        fprintf(2,'\n ... evaluating the response surface at iter: %d ...\n',run);
    end
end
end