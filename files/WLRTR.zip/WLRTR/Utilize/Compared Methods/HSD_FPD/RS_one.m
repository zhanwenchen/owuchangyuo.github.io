% Function evaluating one point on the response surface

function [y_hx,Dsx,Dnx] = RS_one(x,y,h)

ht = (size(h,1)-1)/2;
%% J1 ||Y-HX||^2
for i = 1:size(x,3)

 X1 = fft2(squeeze(x(:,:,i)),size(x,1),size(x,2));
 Y(:,:,i) = fft2(squeeze(y(:,:,i)),size(y,1),size(y,2));
 %H1 = fft2(squeeze(h(:,:,i)),size(x,1),size(x,2));
 H1 = psf2otf(squeeze(h(:,:,i)),[size(x,1),size(x,2)]);
 y_est(:,:,i) = real(ifft2(X1.*H1));
end

% y = y(1:end-ht,1:end-ht,:); %old
% y = y(1:end,1:end,:); %new
% y_est = y_est(1+ht:end,1+ht:end,:); %old
% y_est = y_est(1+ht:end-ht,1+ht:end-ht,:); %new

E = y - y_est;
% E = E(1+ht:end,1+ht:end,:);

y_hx = norm(E(:),2)^2;


%% J2 ||D_sX||^2
laplacian = [0,-1,0;-1,4,-1;0,-1,0];
d = reshape(repmat(laplacian,1,size(x,3)),3,3,size(x,3));
for i=1:size(x,3),
    X1 = fft2(squeeze(x(:,:,i)),size(x,1),size(x,2));
    Ds1 = fft2(squeeze(d(:,:,i)),size(x,1),size(x,2));
    dsx(:,:,i) = real(ifft2(X1.*Ds1));
end
% dsx = dsx(1+ht:end-ht,1+ht:end-ht,:);
Dsx = norm(dsx(:),2)^2; %j2

%% J3 ||D_nX||^2
Dn = fft([-1;1],size(x,3));
for i=1:size(x,1)
    for j=1:size(x,2)
        X3 = fft(squeeze(x(i,j,:)),size(x,3));
        dnx(i,j,:) = real(ifft2(X3.*Dn));
    end
end
dnx = dnx(:,:,3:end);
Dnx = norm(dnx(:),2)^2; %j3

end