clc
clear all
close all
addpath(genpath('CNMF\'));
addpath(genpath('Quality_Indices\'));

%--------------------------------------------------------------------------
% DEMO: COUPLED NONNEGATIVE MATRIX FACTORIZATION (CNMF)
% 
% This is a demo program of CNMF with synthetic HS and MS data
% generated form airborne HS data
%
% References:
% [1] N. Yokoya, T. Yairi, and A. Iwasaki, "Coupled nonnegative matrix 
%     factorization unmixing for hyperspectral and multispectral data fusion," 
%     IEEE Trans. Geosci. Remote Sens., vol. 50, no. 2, pp. 528-537, 2012.
% [2] N. Yokoya, N. Mayumi, and A. Iwasaki, "Cross-calibration for data fusion
%     of EO-1/Hyperion and Terra/ASTER," IEEE J. Sel. Topics Appl. Earth Observ.
%     Remote Sens., vol. 6, no. 2, pp. 419-426, 2013.
% [3] N. Yokoya, T. Yairi, and A. Iwasaki, "Hyperspectral, multispectral, 
%     and panchromatic data fusion based on non-negative matrix factorization," 
%     Proc. WHISPERS, Lisbon, Portugal, Jun. 6-9, 2011.
%
% Author: Naoto Yokoya
% Email : yokoya@sal.rcast.u-tokyo.ac.jp
%--------------------------------------------------------------------------

path = fileparts(mfilename('fullpath'));

%% Read high resolution hyperspectral data (AVIRIS / Indian Pines)
xdata = 120; ydata = 120; band = 224;
filename = '\Demo\IndianPine1997_120.raw';
fid = fopen([path filename],'r');
data = double(reshape(fread(fid,xdata*band*ydata,'uint16'),xdata,ydata,band));

%% Synthesize MSI
disp('Synthesize MSI ...');
AVIRIS_spec = '\Demo\AVIRIS_spec.ascii';
spec0 = load([path AVIRIS_spec]);
spec = spec0(:,1); % Center wavelength of AVIRIS
wavelength = [450 520; 520 600; 630 690; 760 900; 1550 1750; 2080 2350]; % ETM/Landsat
m_band = size(wavelength,1); % Number of MSI bands
srf = zeros(m_band,band);
for b=1:6
    b_i = find(spec>wavelength(b,1),1);
    b_e = find(spec<wavelength(b,2),1,'last');
    srf(b,b_i:b_e) = 1/(b_e+1-b_i);
end
MSI = reshape(reshape(data,[],band)*srf',xdata,ydata,[]);

%% Synthesize low-spatial-resolution HSI
disp('Synthesize HSI ...');
w = 6; % hgsd/mgsd: GSD difference
hx = xdata/w;
hy = ydata/w;
HSI = gaussian_down_sample(data,w); % Gaussian down sampling

%% CNMF
disp('Start CNMF ...');
tic
I_CNMF = CNMF_fusion(HSI,MSI);
disp('Comp. time (CNMF): ');
toc
QI_CNMF = QualityIndices(I_CNMF,data,w); % measure cc, sam, rmse, ergas