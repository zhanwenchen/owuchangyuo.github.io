    close all;
    clear all;
    addpath(genpath('Data\'));
    addpath(genpath('Utilize\'));
    nSig = 20;
    ratio = 0.2;
    rand('seed',0);
    %     [filename, filepath, FilterIndex ] = uigetfile('data/*.*','Read image');
    %     O_Img =  double(imread(fullfile(filepath,filename))) ;
    
   load('C:\Users\owuchangyuo\Desktop\WLRTR\Data\Part_chart_and_stuffed_toy_msUint8.mat')
   O_Img = O_ImgUint8;

   %% Generate the mask
   MaskType = 1; % 1 for random mask; 2 for text mask; 3 for stripe mask ; 4 for real images
   switch MaskType
       case 1
           O = double(rand(size(O_Img)) > (1-ratio));
       case 2
           load('C:\Users\owuchangyuo\Desktop\WLRTR\Data\Mask.mat')
           O = 255 * Mask;
           O = double(O>128);
       case 3
           O = ones(size(O_Img));
           for i = 1:10:250
               O(:,i+3) =  0;
               O(:,i+5) =  0;
               O(:,i+4) =  0;
           end
       case 4
           O = ones(size(O_Img));
           O(O_Img < 100)=0;
   end

    randn('seed', 0);
    N_Img = O_Img.* O + 0* randn(size(O_Img));                                   %Generate noisy image
    PSNR  =  csnr( N_Img, O_Img, 0, 0 );
    SSIM  = cal_ssim( N_Img, O_Img, 0, 0 ); 
    fprintf( 'Noisy Image: nSig = %2.3f, PSNR = %2.2f, SSIM = %2.3f,\n\n\n', nSig, PSNR,SSIM );
    
    Par   = ParSet_Inpainting(nSig,ratio);       
    [E_Img]= LRTR_Inpainting( N_Img, O_Img, O, Par);  %LRTA inpainting function
